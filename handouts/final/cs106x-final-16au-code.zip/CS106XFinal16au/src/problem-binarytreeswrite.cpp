#include "problems.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================


// solution 1: post-order traversal
void stretchHelper(TreeNode*& node, int k, bool useLeft);

void stretch(TreeNode*& node, int k) {
    if (k < 1) {
        throw k;
    } else if (k == 1) {
        return;   // optimization: nothing to do if k = 1 (optional)
    }
    stretchHelper(node, k, /* useLeft */ true);
}

// Recursive helper to stretch the given node and its subtrees by factor of k.
// useLeft parameter indicates whether to stretch to left or right side.
void stretchHelper(TreeNode*& node, int k, bool useLeft) {
    if (node == nullptr) {
        return;   // base case: empty/null node (do nothing)
    }

    // recursively visit child subtrees (must be post-order traversal, current node last)
    stretchHelper(node->left,  k, /* useLeft */ true);
    stretchHelper(node->right, k, /* useLeft */ false);

    node->data /= k;
    TreeNode* newNode = new TreeNode(node->data);
    if (useLeft) {
        // stretch by a factor of k to left side
        newNode->left = node;
        for (int i = 2; i < k; i++) {
            newNode = new TreeNode(node->data, newNode);
        }
    } else {
        // stretch by a factor of k to right side
        newNode->right = node;
        for (int i = 2; i < k; i++) {
            newNode = new TreeNode(node->data, nullptr, newNode);
        }
    }
    node = newNode;
}

///////////////////////////////////////////////////////////////////////////////

// solution 2: pre-order traversal with curr / walking during stretching process
//void helper(TreeNode*& node, int k, string dir);

//void stretch(TreeNode*& node, int k) {
//    if (k < 1) {
//        throw k;
//    } else {
//        helper(node, k, "left");
//    }
//}

//void helper(TreeNode*& node, int k, string dir) {
//    if (!node) { return; }

//    node->data /= k;                    // replicate node k times, walking down as we go
//    TreeNode* curr = node;
//    for (int i = 0; i < k - 1; i++) {   // very important to use 'curr' and not 'node'
//        if (dir == "left") {
//            curr->left = new TreeNode(node->data, curr->left, curr->right);
//            curr->right = nullptr;      // avoid replicating Right subtree in clones
//            curr = curr->left;
//        } else {
//            curr->right = new TreeNode(node->data, curr->left, curr->right);
//            curr->left = nullptr;       // avoid replicating Left subtree in clones
//            curr = curr->right;
//        }
//    }

//    helper(curr->left,  k, "left");     // recursive stretch L/R  (note 'curr' here)
//    helper(curr->right, k, "right");
//}


// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

TreeNode* parseTreeNode(Queue<string>& tokenQueue) {
    if (tokenQueue.peek() == "(") {
        // start of a new node
        tokenQueue.dequeue();   // the "(" token
        int data = stringToInteger(tokenQueue.dequeue());
        TreeNode* node = new TreeNode(data);
        node->left = parseTreeNode(tokenQueue);
        node->right = parseTreeNode(tokenQueue);
        tokenQueue.dequeue();   // the ")" token
        return node;
    } else if (tokenQueue.peek() == "NULL" || tokenQueue.peek() == "/") {
        tokenQueue.dequeue();
        return NULL;
    } else {
        return NULL;
    }
}

TreeNode* makeTreeFromString(string s) {
    // make easier for tokenizing
    s = stringReplace(s, "(", "( ");
    s = stringReplace(s, ")", " ) ");
    s = stringReplace(s, ", ", " , ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    Vector<string> tokens = stringSplit(s, " ");
    Queue<string> tokenQueue;
    for (string token : tokens) {
        tokenQueue.enqueue(token);
    }
    TreeNode* root = parseTreeNodeFromQueue(tokenQueue);
    return root;
}

void printSideways(TreeNode* node, string indent = "") {
    if (node != NULL) {
        printSideways(node->right, indent + "  ");
        cout << indent << node->data << endl;
        printSideways(node->left, indent + "  ");
    }
}

static void test_binaryTreesWrite_helper(string treestr, int k, bool printTree = false) {
    TreeNode* root = makeTreeFromString(treestr);

    if (printTree) {
        cout << "tree before:" << endl;
        printSideways(root);
    }
    cout << "stretch(" << k << ")" << endl;
    cout.flush();
    try {
        stretch(root, k);
        printSideways(root);
    } catch (...) {
        cout << "(threw exception!)" << endl;
    }
    cout << "=======================================" << endl;
    cout << endl;
}

void test_binaryTreesWrite(int problemNumber) {
    problemHeader(problemNumber, "Binary Trees (write)");
    
    string tree1str = "(12 (81 NULL (56)) (34 (19) (6)))";
    test_binaryTreesWrite_helper(tree1str, 2, /* printTree */ true);
    test_binaryTreesWrite_helper(tree1str, 3);
    test_binaryTreesWrite_helper(tree1str, 1);
    test_binaryTreesWrite_helper(tree1str, 0);

    problemFooter();
}
