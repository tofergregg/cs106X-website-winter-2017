#include "problems.h"

#include <iostream>
#include <string>
using namespace std;

void makeTreeSetFromString(TreeSet<int>& set, string s) {
    Vector<string> tokens = stringSplit(s, ", ");
    for (string token : tokens) {
        int n = stringToInteger(token);
        set.add(n);
    }
}

void makeTreeSetFromString(TreeSet<string>& set, string s) {
    Vector<string> tokens = stringSplit(s, ", ");
    for (string token : tokens) {
        set.add(token);
    }
}

template <typename T>
void printTraversals(TreeSet<T>& set) {
    cout << "pre-order:  ";
    set.print(PRE_ORDER);
    cout << "in-order:   ";
    set.print(IN_ORDER);
    cout << "post-order: ";
    set.print(POST_ORDER);
    cout << "-----" << endl;
}

void test_binarySearchTreesRead(int problemNumber) {
    problemHeader(problemNumber, "Binary Search Trees (read)");
    
    TreeSet<int> set;
    makeTreeSetFromString(set, "49, 36, 42, 72, 77, 86, 75, 40, 24, 55, 27, 21, 82, 60, 39");
    
    cout << "(a)" << endl;
    set.printSideways();
    cout << "-----" << endl;
    
    Vector<string> toRemove = stringSplit("76, 24, 49", ", ");
    for (string s : toRemove) {
        int n = stringToInteger(s);
        set.remove(n);
    }
    cout << "(b)" << endl;
    set.printSideways();

    cout << "(c)" << endl;
    bool balanced = set.isBalanced();
    cout << "isBalanced? " << boolalpha << balanced << endl;

    problemFooter();
}
