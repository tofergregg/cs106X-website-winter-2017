#include "TreeNode.h"

int TreeNode::s_freed = 0;

/*
 * Constructs a new tree node with the given data and left/right links.
 */
TreeNode::TreeNode(int data, TreeNode* left, TreeNode* right) {
    this->data = data;
    this->left = left;
    this->right = right;
}

TreeNode::~TreeNode() {
    s_freed++;
}

bool TreeNode::isLeaf() {
    return left == NULL && right == NULL;
}
