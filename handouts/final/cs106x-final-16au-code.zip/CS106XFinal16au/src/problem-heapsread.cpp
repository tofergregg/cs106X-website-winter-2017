#include "problems.h"
#include "HeapPriorityQueue.h"
#include "strlib.h"
#include "vector.h"
#include <iostream>
using namespace std;

void test_heapsRead(int problemNumber) {
    problemHeader(problemNumber, "Heaps (read)");

    string elementsToAdd = "a:60, b:70, c:40, d:30, e:50, f:80, g:20, h:30, i:90, j:10, k:25, l:45";
    int NUM_REMOVES = 2;
    
    HeapPriorityQueue pq;
    stringToPQ(pq, elementsToAdd);
    
    cout << "(a)" << endl;
    cout << pq << endl;
    pq.printSideways();
    cout << "-----" << endl;
    
    cout << "(b)" << endl;
    for (int i = 0; i < NUM_REMOVES; i++) {
        pq.dequeue();
    }
    cout << pq << endl;
    pq.printSideways();

    problemFooter();
}

