/*
 * LinkedList.cpp implements the LinkedList class behavior declared in LinkedList.h.
 *
 * Today's version adds insert, get/set, remove, the destructor,
 * valid index checking, and memory freeing.
 */

#include "ListNode.h"

int ListNode::s_freed = 0;
