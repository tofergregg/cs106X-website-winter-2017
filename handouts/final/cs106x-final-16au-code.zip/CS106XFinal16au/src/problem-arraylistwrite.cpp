#include "problems.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1
void ArrayIntList::stretch(int k) {
    if (k > 0) {
        // resize as needed to fit
        if (myCapacity < mySize * k) {
            int* bigger = new int[k * mySize]();
            for (int i = 0; i < mySize; i++) {
                bigger[i] = myElements[i];
            }
            delete[] myElements;
            myElements = bigger;
        }
        
        // stretch the elements
        for (int i = mySize - 1; i >= 0; i--) {
            for (int j = 0; j < k; j++) {
                myElements[i * k + j] = myElements[i];
            }
        }
        mySize *= k;
    } else {
        // k <= 0; remove all elements from the list
        mySize = 0;
    }
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

static void testList(Vector<int> v, int k, int capacity = 10) {
    ArrayIntList list(capacity);
    for (int value : v) {
        list.add(value);
    }
    cout << endl;
    cout << "before stretch(" << k << "), list=" << list << endl;
    list.stretch(k);
    cout << "before stretch(" << k << "), list=" << list << endl;
}

void test_arrayListsWrite(int problemNumber) {
    problemHeader(problemNumber, "ArrayIntLists (write)");
    
    Vector<int> v;
    v += 18, 7, 4, 24, 11;
    testList(v, 3);
    
    Vector<int> v2;
    v2 += 42, 42, 10, 10;
    testList(v2, 2);
    
    Vector<int> oneElement;
    oneElement += 42;
    testList(oneElement, 5);
    
    Vector<int> empty;
    testList(empty, 2);
    
    problemFooter();
}
