#ifndef _listnode_h
#define _listnode_h

#include <iostream>
#include <string>
using namespace std;

/*
 * The internal structure representing a single node.
 */
struct ListNode {
    int data;         // element stored in each node
    ListNode* next;   // pointer to the next node (NULL if none)
    
    ListNode(int d = 0, ListNode* n = nullptr) {
        data = d;
        next = n;
    }

    ~ListNode() {
        s_freed++;
    }

    static int s_freed;
};

#endif
