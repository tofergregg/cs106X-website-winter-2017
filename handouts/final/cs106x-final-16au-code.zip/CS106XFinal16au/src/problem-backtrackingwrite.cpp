#include "problems.h"
#include <iomanip>

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1: uses a Vector as aux. storage of 'chosen' elements
void printSubVectors_helper(const Vector<int>& v, int i, Vector<int>& chosen);

void printSubVectors(const Vector<int>& v) {
    Vector<int> chosen;
    printSubVectors_helper(v, 0, chosen);
}

void printSubVectors_helper(const Vector<int>& v, int i, Vector<int>& chosen) {
    if (i >= v.size()) {
        cout << chosen << endl;
    } else {
        int element = v[i];
        
        // choose/explore two possibilities:
        // 1) without the i'th element
        printSubVectors_helper(v, i + 1, chosen);
        
        // 2) with the i'th element
        chosen.add(element);
        printSubVectors_helper(v, i + 1, chosen);
        chosen.remove(chosen.size() - 1);
    }
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================


static void test_backtrackingWrite_helper(string s) {
    cout << "printSubVectors(" << s << ") : " << endl;
    Vector<int> v;
    istringstream iss(s);
    iss >> v;
    try {
        printSubVectors(v);
    } catch (...) {
        cout << "(threw exception)" << endl;
    }
}

void test_backtrackingWrite(int problemNumber) {
    problemHeader(problemNumber, "Backtracking (write)");
    
    test_backtrackingWrite_helper("{1, 2, 3}");
    test_backtrackingWrite_helper("{42, 23}");
    test_backtrackingWrite_helper("{97, -4, 0, 29}");
    test_backtrackingWrite_helper("{}");
    
    problemFooter();
}
