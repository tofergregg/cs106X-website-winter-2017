#include "problems.h"
#include <iomanip>

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

bool digitsSorted(int x) {
    if (x < 0) {
        return digitsSorted(-x);
    } else if (x < 10) {
        return true;
    } else {
        int last = x % 10;
        int rest = x / 10;
        int secondToLast = rest % 10;
        return (secondToLast <= last && digitsSorted(rest));
    }
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================


static void test_recursionWrite_helper(int x) {
    cout << "digitSorted(" << setw(9) << x << ") : ";
    cout.flush();
    try {
        bool result = digitsSorted(x);
        cout << boolalpha << result << endl;
    } catch (...) {
        cout << "(threw exception)" << endl;
    }
}

void test_recursionWrite(int problemNumber) {
    problemHeader(problemNumber, "Recursion (write)");
    
    test_recursionWrite_helper(0);
    test_recursionWrite_helper(2345);
    test_recursionWrite_helper(13469);
    test_recursionWrite_helper(-2345);
    test_recursionWrite_helper(22334455);
    test_recursionWrite_helper(-5);
    test_recursionWrite_helper(4321);
    test_recursionWrite_helper(24378);
    test_recursionWrite_helper(21);
    test_recursionWrite_helper(-33331);
    
    problemFooter();
}
