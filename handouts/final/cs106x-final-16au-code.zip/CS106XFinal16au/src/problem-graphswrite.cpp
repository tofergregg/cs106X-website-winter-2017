#include "problems.h"
#include <iostream>
#include <sstream>
#include "basicgraph.h"
#include "graphsupport.h"
#include "simpio.h"
#include "vector.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

//// matching         - set of edges where no edges share a vertex
//// maximal matching - a matching where no other edge in graph can be added;
////                    if any remaining edge were added, it would no longer be a matching
////                    (would introduce a duplicate vertex)
////                    (i.e., connects as many vertexes as possible)
////               - can be found using a simple greedy algorithm. easier test question?
//// minimum
//// maximal matching - a maximal matching using the fewest possible edges in the graph

//Set<Edge*> findMinMaxMatching(BasicGraph& graph) {
//    Set<Edge*> result;
//    int resultVertexCount = 0;

//    // need to keep track of set of vertexes connected
//    // so we know if we added any duplicates

//    if (graph.getEdgeSet().isEmpty()) {
//        return result;
//    }
    
//    graph.resetData();

//    // try to find longest path from every possible starting vertex
//    for (Vertex* v : graph) {
//        Set<Vertex*> chosen;
//        int vertexCount = 0;
//        findMinMaxMatchingHelper(graph, v,
//                                 chosen, vertexCount,
//                                 result, resultVertexCount);
//    }
//    return result;
//}

// assume graph is undirected / there is an edge each way

bool colorHelper(BasicGraph& graph, Vector<string>& colors,
                 Map<Vertex*, string>& map, Vertex* v) {
    if (map.size() == graph.size()) {
        return true;    // base case 1: colored every vertex
    } else if (map.containsKey(v)) {
        return false;   // base case 2: already colored
    } else {
        // create subset of available legal colors for this vertex
        Set<string> availColors;
        for (string color : colors) {
            availColors.add(color);
        }
        for (Vertex* neighbor : graph.getNeighbors(v)) {
            if (map.containsKey(neighbor)) {
                availColors.remove(map[neighbor]);
            }
        }

        // choose-explore-unchoose each of these colors for this vertex
        // (if there are no available colors, loop will be skipped)
        for (string color : availColors) {
            map[v] = color;
            for (Vertex* neighbor : graph.getNeighbors(v)) {
                if (colorHelper(graph, colors, map, neighbor)) {
                    return true;
                }
            }
        }
        map.remove(v);
        return false;
    }
}

Map<Vertex*, string> colorGraph(BasicGraph& graph, Vector<string>& colors) {
    Map<Vertex*, string> map;
    if (!graph.isEmpty()) {
        colorHelper(graph, colors, map, graph.getVertexSet().first());
    }
    return map;
}

//// ============================================================================
//// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
//// ============================================================================

//void readPath(BasicGraph& graph, string pathStr, Vector<Vertex*>& vpath);
void testGraph(string graphStr, int k);

void test_graphsWrite(int problemNumber) {
    problemHeader(problemNumber, "Graphs (write)");

    string graph1 = "{A, B, C, D, A - B, A - C, B - C, C - D}";
    testGraph(graph1, 2);
    testGraph(graph1, 3);
    testGraph(graph1, 4);

    cout << endl;
    string graph2 = "{V1, V2, V3, V4, V5, V6, V7, V8, V9, V10, V1 - V2, V1 - V5, V1 - V6, V2 - V3, V2 - V7, V3 - V4, V3 - V8, V4 - V5, V4 - V9, V5 - V10, V6 - V8, V6 - V9, V7 - V9, V7 - V10, V8 - V10}";
    testGraph(graph2, 2);
    testGraph(graph2, 3);
    testGraph(graph2, 4);
    cout << endl;

    cout << endl;
    string graph3 = "{A, B, C, D, E, F, G, H, I, A - B, A - D, B - C, B - D, B - E, B - F, C - F, D - G, E - F, E - G, E - H, E - I, F - I, H - I}";
    testGraph(graph3, 2);
    testGraph(graph3, 3);
    testGraph(graph3, 4);
    cout << endl;

    string empty = "{}";
    testGraph(empty, 2);

    problemFooter();
}

void testGraph(string graphStr, int k) {
    static Vector<string> ALL_COLORS {"red", "green", "blue",
                                      "orange", "purple", "yellow",
                                      "white", "black", "pink"};
    Vector<string> colors = ALL_COLORS.subList(0, k);

    BasicGraph graph;
    istringstream input(graphStr);
    input >> graph;
    cout << "graph: " << graph << endl;
    try {
        Map<Vertex*, string> coloring = colorGraph(graph, colors);
        cout << "  colorGraph w/ " << k << " colors returned: " << coloring << endl;
    } catch (...) {
        cout << "(threw exception!)" << endl;
    }
}

ostream& operator <<(ostream& out, const Vertex* v) {
    if (v) {
        out << v->name;
    } else {
        out << "null";
    }
    return out;
}
