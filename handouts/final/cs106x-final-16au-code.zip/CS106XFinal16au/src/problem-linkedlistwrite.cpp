#include "problems.h"
#include "vector.h"
#include <iostream>
#include <sstream>
using namespace std;

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1
void clump(ListNode*& list, int max) {
    if (max <= 0) {
       throw max;
    }

    ListNode* clump = list;
    while (clump != nullptr) {
        ListNode* curr = clump;
        int count = 1;

        while (curr != nullptr && curr->next != nullptr) {
            if (curr->next->data == clump->data) {
                // this node may belong in the current "clump"
                count++;

                if (count > max) {
                    // exceeded max, so remove
                    ListNode* trash = curr->next;
                    curr->next = curr->next->next;
                    delete trash;
                } else if (curr->next == clump->next) {
                    // already in right place; don't touch, move onward
                    curr = curr->next;
                } else {
                    // less than max, so remove and add it to clump
                    ListNode* temp = curr->next;
                    curr->next = curr->next->next;
                    temp->next = clump->next;
                    clump->next = temp;
                    clump = temp;
                }
            } else {
                // not part of same "clump"; move onward
                curr = curr->next;
            }
        }

        // done with this clump; move forward to next one
        clump = clump->next;
    }
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void printChain(ListNode* list, string name, int maxLength = 30) {
    const bool PRINT_AS_LINKED_LIST = false;

    int len = 0;
    if (PRINT_AS_LINKED_LIST) {
        cout << name << " -> ";
    } else {
        cout << "{";
    }
    ListNode* curr = list;
    bool cycle = false;
    for (int i = 0; curr != nullptr && i < maxLength; i++, curr = curr->next) {
        if (PRINT_AS_LINKED_LIST) {
            cout << "[" << curr->data << "]";
        } else {
            cout << curr->data;
        }
        if (curr->next != nullptr) {
            cout << (PRINT_AS_LINKED_LIST ? " -> " : ", ");
        }
        if (i == maxLength - 1) {
            cycle = true;
            cout << " ... (cycle)";
        }
        len++;
    }
    if (PRINT_AS_LINKED_LIST) {
        if (!cycle) {
            cout << " /";
        }
    } else {
        cout << "}";
    }
    cout << " (length " << len << ")" << endl;
}

void printChainPointers(ListNode* list, string name, int maxLength = 30) {
    cout << name << " -> ";
    ListNode* curr = list;
    bool cycle = false;
    for (int i = 0; curr != nullptr && i < maxLength; i++, curr = curr->next) {
        cout << "[" << curr << ":" << curr->data << "]";
        if (curr->next != nullptr) {
            cout << " -> ";
        }
        if (i == maxLength - 1) {
            cycle = true;
            cout << " ... (cycle)";
        }
    }
    if (!cycle) {
        cout << " /";
    }
    cout << endl;
}

ListNode* vectorToList(Vector<int>& v) {
    ListNode* front = nullptr;
    ListNode* curr = nullptr;
    while (!v.isEmpty()) {
        int n = v[0];
        v.remove(0);
        if (!curr) {
            front = new ListNode(n);
            curr = front;
        } else {
            curr->next = new ListNode(n);
            curr = curr->next;
        }
    }
    return front;
}

static void testList(Vector<int> v, int max, bool catchExceptions = true) {
    ListNode::s_freed = 0;
    ListNode* front = vectorToList(v);
    cout << endl;
    printChain(front, "front");
    cout << "clump(" << max << ")" << endl;
    if (catchExceptions) {
        try {
            clump(front, max);
            printChain(front, "front");
            cout << "after, freed=" << setw(3) << ListNode::s_freed << endl;
        } catch (string s) {
            cout << "threw a string exception: " << s << endl;
        } catch (const char* s) {
            cout << "threw a string exception: " << s << endl;
        } catch (int n) {
            cout << "threw an integer exception: " << n << endl;
        } catch (...) {
            cout << "threw an exception." << endl;
        }
    } else {
        // just call it without try/catch
        clump(front, max);
        printChain(front, "front");
        cout << "freed=" << setw(3) << ListNode::s_freed << " nodes." << endl;
    }
}

void test_linkedListsWrite(int problemNumber) {
    problemHeader(problemNumber, "Linked Lists (write)");
    
    Vector<int> v {1, 6, 5, 2, 6, 4, 5, 3, 5, 8, 5, 2, 1, 1, 8, 4, 5, 6, 1, 8, 6};
    // Vector<int> v {5, 8, 8, 8};
    testList(v, 99);
    testList(v, 3);
    testList(v, 2);
    testList(v, 1);

    v = {7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7};
    testList(v, 20);
    testList(v, 3);
    testList(v, 2);
    testList(v, 1);

    v = {42};
    testList(v, 2);

    v.clear();
    testList(v, 5);

    // exceptions
    v = {1, 6, 5, 2, 6, 4, 5, 3, 5};
    testList(v, 0);
    testList(v, -1);

    problemFooter();
}
