#include "problems.h"
#include "graphsupport.h"
#include <iostream>
#include <sstream>
using namespace std;

void test_graphsRead(int problemNumber) {
    problemHeader(problemNumber, "Graphs (read)");
    
    BasicGraph graph;
    string graphStr = "{A, B, C, D, E, F, G, H, A -> B : 2, A -> C : 4, A -> D : 5, A -> E : 9, B -> C : 3, C -> E : 4, C -> H : 2, D -> G : 1, F -> C : 3, F -> E : 2, G -> H : 2, H -> E : 1, H -> F : 4}";
    istringstream iss(graphStr);
    iss >> graph;
    cout << "graph: " << graph << endl;
    
    cout << "(a)" << endl;
    printAdjacencyList(graph);
    printAdjacencyMatrix(graph);
    // cout << "connected? " << boolalpha << isConnected(graph, /* checkWeak */ true) << endl;
    
    cout << "(b)" << endl;
    // cout << "cyclic?    " << boolalpha << isCyclic(graph) << endl;
    cout << "(no code provided for BFS output)" << endl;
    
    cout << "(c)" << endl;
    cout << "(no code provided for Dijkstra output)" << endl;

//    cout << "degrees:   " << endl;
//    printVertexDegrees(graph);
    
//    cout << "(d)" << endl;
//    printEdgeList(graph);
//    printAdjacencyList(graph);
    
//    cout << "(e)" << endl;
//    cout << "(no code provided for Dijkstra output)" << endl;

    problemFooter();
}
