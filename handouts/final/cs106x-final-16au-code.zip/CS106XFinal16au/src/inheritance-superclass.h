#ifndef _inheritance_superclass_h
#define _inheritance_superclass_h

#include <iostream>
#include <string>
#include "set.h"
using namespace std;

class Calculator {
public:
    Calculator(int seed);
    virtual int fib(int k);
    virtual int getSeed() const;
    virtual bool isPrime(int n);
    virtual int kthPrime(int k);
    virtual int rand(int max);
    virtual string toString() const;
private:
    int seed;
    int kthPrimeCalls;   // used by tester
public:
    int getKthPrimeCalls() const;
};

#endif
