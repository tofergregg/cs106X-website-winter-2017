#include "problems.h"

#include <iostream>
using namespace std;

// order: A M G F

class Santa {
public:
    virtual void m1() {
        m3();
        cout << "Santa m1   ";
    }

    virtual void m3() {
        cout << "Santa m3   ";
    }
};

class Rudolph : public Santa {
public:
    virtual void m2() {
        cout << "Rudolph m2   ";
        m1();
    }

    virtual void m3() {
        cout << "Rudolph m3   ";
        Santa::m3();
    }
};

class Frosty : public Santa {
public:
    virtual void m1() {
        cout << "Frosty m1   ";
    }

    virtual void m3() {
        cout << "Frosty m3   ";
    }
};

class Grinch : public Frosty {
public:
    virtual void m2() {
        cout << "Grinch m2   ";
        m1();
    }

    virtual void m3() {
        cout << "Grinch m3   ";
        Frosty::m3();
    }

    virtual void m4() {
        cout << "Grinch m4   ";
        m3();
    }
};

void test_inheritanceRead(int problemNumber) {
    problemHeader(problemNumber, "Inheritance/Polymorphism (read)");

    Santa*  var1 = new Frosty();
    Frosty* var2 = new Grinch();
    Santa*  var3 = new Grinch();
    Santa*  var4 = new Rudolph();

    POLYM(var1->m1(););
    POLYC(var1->m2(););
    POLYM(var1->m3(););
    POLYM(var2->m1(););
    POLYC(var2->m2(););
    POLYM(var2->m3(););
    POLYC(var3->m2(););
    POLYM(var4->m1(););
    POLYM(((Frosty*) var1)->m1(););    // cast does nothing; same output
    POLYC(((Frosty*) var1)->m4(););    // compiler error; Frosty has no m4
    POLYR(((Grinch*) var1)->m4(););    // crash; cast is a "lie" (doesn't have that method)
    POLYM(((Grinch*) var2)->m4(););    // cast allows code to compile and run
    POLYR(((Rudolph*) var3)->m2(););   // crash; cast is a "lie" (but DOES have that method)

    // POLYC(((Frosty*) var3)->m2(););    // compiler error; Frosty has no m2
    // POLYR(((Frosty*) var4)->m1(););    // crash; cast is a "lie" (but DOES have that method)
    // POLYC(((Frosty*) var4)->m2(););    // compiler error; Frosty has no m2

    problemFooter();
}
