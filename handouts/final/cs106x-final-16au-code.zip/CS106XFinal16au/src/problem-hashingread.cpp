#include "problems.h"
#include "HashTableMap.h"

void test_hashingRead(int problemNumber) {
    problemHeader(problemNumber, "Hashing (read)");
    
    HashTableMap<int, int> map(/* capacity */ 10, /* rehashLoadFactor */ 0.75);

    ///////////////////////////////////////////////////////////////////////////

    map.put(3, 12);
    map.put(4, 11);
    map.put(77, 1);
    map.put(7, 8);
    map.put(5, 22);
    map.put(17, 3);
    map.put(19, 108);
    map.put(47, 100);
    map.put(44, 46);
    map.put(11, 22);
    map.put(2, 17);
    map.put(1, 19);
    map.put(11, 100);
    map.put(9, 181);
    map.remove(17);
    map.remove(181);
    if (map.containsKey(122)) {
        map.put(1, 1);
    } else {
        map.put(28, 3);
    }
    int x = 1;
    while (map.containsKey(3)) {
        if (map.containsKey(x)) {
            map.remove(x);
        }
        x++;
    }
    map.put(47, 100);
    
    ///////////////////////////////////////////////////////////////////////////

    map.printStructure();
    problemFooter();
}
