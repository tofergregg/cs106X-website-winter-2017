#include "problems.h"

#include <iostream>
#include <string>
#include "vector.h"
#include "ListNode.h"
using namespace std;

extern void printChain(ListNode* list, string name, int maxLength = 20);
extern ListNode* vectorToList(Vector<int>& v);

void linkedListMystery3(ListNode*& front) {
    ListNode* curr = front;
    ListNode* next = curr->next;
    while (next != nullptr) {
        if (curr->data % 5 == 0) {
            front = front->next;
        } else if (curr->data % 2 == 0 && next->data % 2 == 0) {
            curr->next = next->next;
        } else if (curr->data % 3 == 0) {
            next->data++;
            curr->data--;
            curr = next;
        }
        curr = next;
        next = next->next;
    }
}

void test_linkedListsRead(int problemNumber) {
    problemHeader(problemNumber, "Linked Lists (read)");
    
    Vector<int> v {55, 10, 2, 3, 4, 20, 7, 6, 8, 9, 12, 15};
    ListNode* front = vectorToList(v);

    linkedListMystery3(front);
    
    printChain(front, "front");
    problemFooter();
}
