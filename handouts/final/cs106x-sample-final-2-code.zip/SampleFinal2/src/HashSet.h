/*
 * CS 106B, Marty Stepp
 * This file contains the declaration of the HashSet class, which implements
 * a set of integers using a hash table.
 * The hash table uses separate chaining (a linked list of values in each
 * hash bucket) to resolve hash collisions.
 * See HashSet.cpp for the implementation of each member.
 */

#ifndef _hashset_h
#define _hashset_h

#include <iostream>
#include <string>

/*
 * A HashNode stores a single integer of data and a link to another node.
 */
struct HashNode {
    int data;
    HashNode* next;
    HashNode(int data = 0, HashNode* next = NULL) {
        this->data = data;
        this->next = next;
    }
};

class HashSet {
public:
    HashSet();
    void add(int value);
    bool contains(int value) const;
    void remove(int value);
    void printStructure() const;

    void trimChains(int k);

private:
    HashNode** m_elements;
    int m_size;
    int m_capacity;
    int hashCode(int value) const;
};

#endif





