/*
 * CS 106B, Marty Stepp
 */

#ifndef _HeapPriorityQueue_h
#define _HeapPriorityQueue_h

#include <fstream>
#include <iostream>
#include <string>
#include "pqueue.h"

using namespace std;

struct PQEntry {
    string data;
    double priority;
};

class HeapPriorityQueue {
public:
    HeapPriorityQueue(PQEntry* elements = NULL, int capacity = 10, int mysize = 0);
    ~HeapPriorityQueue();
    void changePriority(string value, double newPriority);
    string dequeue();
    void enqueue(string value, double priority);
    bool isEmpty() const;
    string peek() const;
    double peekPriority() const;
    void printSideways(int index = 1, string indent = "") const;
    int size() const;
    string toString() const;
    
    friend ostream& operator <<(ostream& out, const HeapPriorityQueue& pq);
    
    // your exam problem
    int atLevel(int level) const;

private:
    PQEntry* elements;   // array of element data
    int capacity;        // length of elements array
    int mysize;          // number of elements that have been added
    
    PriorityQueue<string>* hackPQ;
};

// "a:4, b:16, c:7" => PQ
void stringToPQ(HeapPriorityQueue& pq, string elements);

#endif
