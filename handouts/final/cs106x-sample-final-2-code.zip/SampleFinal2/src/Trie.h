/*
 * CS 106B, Marty Stepp
 * This file contains the declaration of the Trie class, which represents
 * a prefix tree set of strings.
 * This is a very efficient representation of a set of words that can also
 * be used to perform prefix searches ("do any words start with ___?").
 */

#ifndef _trie_h
#define _trie_h

#include <iostream>
#include <string>

using namespace std;

// represents one node in the tree with a child for each letter A-Z
struct TrieNode {
    bool isWord;
    TrieNode* children[26];   // 0=a, 1=b, 2=c, ..., 25=z

    TrieNode() {
        this->isWord = false;
        for (int i = 0; i < 26; i++) {
            this->children[i] = NULL;
        }
    }
};

class Trie {
public:
    Trie();
    ~Trie();

    /*
     * Adds the given word to the set of words in this trie.
     * Assumes the word consists entirely of lowercase letters from A-Z.
     */
    void add(string word);

    /*
     * Returns true if the given word was previously added to this trie.
     * Assumes the word consists entirely of lowercase letters from A-Z.
     */
    bool contains(string word) const;

    /*
     * Returns true if any word in this trie begins with the given letters.
     * Assumes the word consists entirely of lowercase letters from A-Z.
     */
    bool containsPrefix(string word) const;

private:
    TrieNode* m_root;
    int m_size;

    void add(TrieNode*& node, string word);
    bool contains(TrieNode* node, string word) const;
    bool containsPrefix(TrieNode* node, string word) const;
};

#endif
