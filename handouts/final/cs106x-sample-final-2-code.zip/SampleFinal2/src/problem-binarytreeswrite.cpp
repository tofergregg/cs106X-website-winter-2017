#include "problems.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1
bool hasPathHelper(TreeNode* node, int start, bool seenStart, int end) {
    if (node == NULL) {
        return false;
    } else {
        seenStart = seenStart || node->data == start;
        bool seenEnd = seenStart && node->data == end;
        return (seenStart && seenEnd) ||
                hasPathHelper(node->left, start, seenStart, end) ||
                hasPathHelper(node->right, start, seenStart, end);
    }
}

bool hasPath(TreeNode* node, int start, int end) {
    return hasPathHelper(node, start, false, end);
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

TreeNode* parseTreeNode(Queue<string>& tokenQueue) {
    if (tokenQueue.peek() == "(") {
        // start of a new node
        tokenQueue.dequeue();   // the "(" token
        int data = stringToInteger(tokenQueue.dequeue());
        TreeNode* node = new TreeNode(data);
        node->left = parseTreeNode(tokenQueue);
        node->right = parseTreeNode(tokenQueue);
        tokenQueue.dequeue();   // the ")" token
        return node;
    } else if (tokenQueue.peek() == "NULL" || tokenQueue.peek() == "/") {
        tokenQueue.dequeue();
        return NULL;
    } else {
        return NULL;
    }
}

TreeNode* makeTreeFromString(string s) {
    // make easier for tokenizing
    s = stringReplace(s, "(", "( ");
    s = stringReplace(s, ")", " ) ");
    s = stringReplace(s, ", ", " , ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    Vector<string> tokens = stringSplit(s, " ");
    Queue<string> tokenQueue;
    for (string token : tokens) {
        tokenQueue.enqueue(token);
    }
    TreeNode* root = parseTreeNodeFromQueue(tokenQueue);
    return root;
}

void printSideways(TreeNode* node, string indent = "") {
    if (node != NULL) {
        printSideways(node->right, indent + "  ");
        cout << indent << node->data << endl;
        printSideways(node->left, indent + "  ");
    }
}

static void test_binaryTreesWrite_helper(string treestr, int start, int end, bool printTree = false) {
    TreeNode* root = makeTreeFromString(treestr);

    if (printTree) {
        printSideways(root);
    }
    cout << "hasPath(" << setw(3) << start << ", " << setw(3) << end << ") = ";
    cout.flush();
    try {
        bool result = hasPath(root, start, end);
        cout << boolalpha << result << endl;
    } catch (...) {
        cout << "(threw exception!)" << endl;
    }
}

void test_binaryTreesWrite(int problemNumber) {
    problemHeader(problemNumber, "Binary Trees (write)");
    
    string tree1str = "(67 (80 (16) (21 (45))) (52 (99)))";
    test_binaryTreesWrite_helper(tree1str, 67, 99, /* print tree */ true);
    test_binaryTreesWrite_helper(tree1str, 80, 45);
    test_binaryTreesWrite_helper(tree1str, 52, 99);
    test_binaryTreesWrite_helper(tree1str, 67, 45);
    test_binaryTreesWrite_helper(tree1str, 16, 16);
    test_binaryTreesWrite_helper(tree1str, 99, 67);
    test_binaryTreesWrite_helper(tree1str, 80, 99);
    test_binaryTreesWrite_helper(tree1str, 67, 100);
    test_binaryTreesWrite_helper(tree1str, -1, 45);
    test_binaryTreesWrite_helper(tree1str, 42, 64);
    
    problemFooter();
}
