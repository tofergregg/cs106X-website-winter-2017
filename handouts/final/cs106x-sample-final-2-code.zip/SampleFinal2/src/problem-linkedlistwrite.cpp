#include "problems.h"
#include "vector.h"
#include <iostream>
#include <sstream>
using namespace std;

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1
void combineDuplicates(ListNode*& front) {
    if (!front) {
        return;    // empty list case
    }
    
    // combine at front of list, if needed
    // (common bug: data changes as you are looping)
    int mergeValue = front->data;
    while (front->next != nullptr && front->next->data == mergeValue) {
        // merge with next node (and delete next node)
        front->data += front->next->data;
        ListNode* trash = front->next;
        front->next = front->next->next;
        delete trash;
    }
    
    // combine throughout rest of list
    ListNode* curr = front;
    while (curr->next != nullptr) {
        mergeValue = curr->next->data;
        while (curr->next->next != nullptr && curr->next->next->data == mergeValue) {
            // merge with next node (and delete next node)
            curr->next->data += curr->next->next->data;
            ListNode* trash = curr->next->next;
            curr->next->next = curr->next->next->next;
            delete trash;
        }
        curr = curr->next;
    }
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void printChain(ListNode* list, string name, int maxLength = 20) {
    cout << name << " -> ";
    ListNode* curr = list;
    bool cycle = false;
    for (int i = 0; curr != nullptr && i < maxLength; i++, curr = curr->next) {
        cout << "[" << curr->data << "]";
        if (curr->next != nullptr) {
            cout << " -> ";
        }
        if (i == maxLength - 1) {
            cycle = true;
            cout << " ... (cycle)";
        }
    }
    if (!cycle) {
        cout << " /";
    }
    cout << endl;
}

ListNode* vectorToList(Vector<int>& v) {
    ListNode* front = nullptr;
    ListNode* curr = nullptr;
    while (!v.isEmpty()) {
        int n = v[0];
        v.remove(0);
        if (!curr) {
            front = new ListNode(n);
            curr = front;
        } else {
            curr->next = new ListNode(n);
            curr = curr->next;
        }
    }
    return front;
}

static void testList(Vector<int> v, bool catchExceptions = true) {
    ListNode* front = vectorToList(v);
    cout << endl;
    printChain(front, "front");
    cout << "before combineDuplicates(), freed=" << setw(3) << ListNode::s_freed << endl;
    if (catchExceptions) {
        try {
            combineDuplicates(front);
            printChain(front, "front");
            cout << "after  combineDuplicates(), freed=" << setw(3) << ListNode::s_freed << endl;
        } catch (string s) {
            cout << "threw a string exception: " << s << endl;
        } catch (const char* s) {
            cout << "threw a string exception: " << s << endl;
        } catch (int n) {
            cout << "threw an integer exception: " << n << endl;
        } catch (...) {
            cout << "threw an exception." << endl;
        }
    } else {
        // just call it without try/catch
        combineDuplicates(front);
        printChain(front, "front");
        cout << "after  combineDuplicates(), freed=" << setw(3) << ListNode::s_freed << endl;
    }
}

void test_linkedListsWrite(int problemNumber) {
    problemHeader(problemNumber, "Linked Lists (write)");
    
    Vector<int> v {3, 3, 3, 2, 4, 4, 4, -1, 4, 12, 12, 12, 12, 48, -5, -5, -5, -5};
    testList(v);
    testList(v);
    
    v = {1, 1, 2, 2, 4, 4, 8, 8, 8, 24, 24, 24, 24, 48};
    testList(v);
    
    v = {2, 2, 2, 2, 2, 2, 2, 2};
    testList(v);
    
    v = {10, 20, 30, 40, 50};
    testList(v);
    
    v = {42, 42};
    testList(v);
    
    v = {42};
    testList(v);
    
    v.clear();
    testList(v);

    problemFooter();
}
