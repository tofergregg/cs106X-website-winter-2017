#ifndef _problems_h
#define _problems_h

#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include "basicgraph.h"
#include "grid.h"
#include "hashmap.h"
#include "hashset.h"
#include "map.h"
#include "set.h"
#include "stack.h"
#include "queue.h"
#include "random.h"
#include "strlib.h"
#include "vector.h"
#include "ArrayIntList.h"
#include "BinaryTree.h"
#include "ListNode.h"
using namespace std;

void problemHeader(int number, string title);
void problemFooter();

void test_arrayListsWrite(int problemNumber);
void test_backtrackingWrite(int problemNumber);
void test_binarySearchTreesRead(int problemNumber);
void test_binaryTreesWrite(int problemNumber);
void test_graphsRead(int problemNumber);
void test_graphsWrite(int problemNumber);
void test_hashingRead(int problemNumber);
void test_heapsRead(int problemNumber);
void test_heapsWrite(int problemNumber);
void test_inheritanceWrite(int problemNumber);
void test_inheritanceRead(int problemNumber);
void test_linkedListsRead(int problemNumber);
void test_linkedListsWrite(int problemNumber);
void test_pointersWrite(int problemNumber);
void test_recursionWrite(int problemNumber);
void test_searchingAndSortingRead(int problemNumber);

// macros for polymorphism problems
#define POLYM(stmt) \
  { cout << #stmt << ";" << endl; stmt; cout << endl; }

#define POLYC(stmt) \
  { cout << #stmt << ":" << endl; cout << "COMPILER ERROR" << endl << endl; }

#define POLYR(stmt) \
  { cout << #stmt << ":" << endl; cout << "CRASH / RUNTIME ERROR" << endl << endl; }

#endif
