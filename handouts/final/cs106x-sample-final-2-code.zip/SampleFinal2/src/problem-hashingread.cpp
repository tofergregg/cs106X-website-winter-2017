#include "problems.h"
#include "HashTableMap.h"

void test_hashingRead(int problemNumber) {
    problemHeader(problemNumber, "Hashing (read)");
    
    HashTableMap<int, int> map(/* capacity */ 10, /* rehashLoadFactor */ 0.5);
    map.put(19, 9);
    map.put(4, 4);
    map.put(44, 19);
    map.remove(9);
    map.put(23, 54);
    map.put(73, 54);
    map.put(83, 9);
    map.put(99, 4);
    map.remove(4);
    map.put(0, 0);
    map.put(-2, -88);
    if (!map.containsKey(73)) {
        map.put(66, 77);
    }
    map.put(333, 0);
    
    map.printStructure();

    problemFooter();
}
