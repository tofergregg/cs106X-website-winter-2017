#include "inheritance-superclass.h"
#include <climits>
#include <iomanip>
#include <sstream>
#include "random.h"

Calculator::Calculator(int seed) {
    this->seed = seed;
    kthPrimeCalls = 0;
    setRandomSeed(seed);
}

int Calculator::fib(int k) {
    // not relevant
    return k;
}

int Calculator::getSeed() const {
    return seed;
}

bool Calculator::isPrime(int n) {
    // generate prime numbers until we find n or pass n
    for (int k = 1; k <= INT_MAX; k++) {
        int kth = kthPrime(k);
        if (kth == n) {
            return true;
        } else if (kth > n) {
            break;
        }
    }
    return false;
}

// intentionally slow implementation to underscore need for memoization
int Calculator::kthPrime(int k) {
    kthPrimeCalls++;
    if (k <= 0) {
        throw k;
    }
    int primeCount = 0;
    for (int i = 2; i <= INT_MAX; i++) {
        int factors = 0;
        for (int j = 1; j <= i; j++) {
            if (i % j == 0) {
                factors++;
            }
        }
        if (factors == 2) {
            // i is prime
            primeCount++;
            if (primeCount == k) {
                return i;
            }
        }
    }
    // couldn't find k'th prime; probably too large for range of ints
    throw k;
}

int Calculator::rand(int max) {
    return randomInteger(0, max);
}

string Calculator::toString() const {
    return "toString():unused";
}

int Calculator::getKthPrimeCalls() const {
    return kthPrimeCalls;
}
