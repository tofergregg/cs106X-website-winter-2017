#include "problems.h"

#include <iostream>
#include <string>
#include "vector.h"
#include "ListNode.h"
using namespace std;

extern void printChain(ListNode* list, string name, int maxLength = 20);
extern ListNode* vectorToList(Vector<int>& v);

void linkedListMystery2(ListNode*& front) {
    ListNode* curr = front;
    ListNode* prev = nullptr;
    while (curr->next != nullptr) {
        if (curr->data % 2 == 0 && prev != nullptr) {
            prev->next = curr->next;
        } else {
            curr->data--;
        }
        prev = curr;
        curr = curr->next;
    }
}

void test_linkedListsRead(int problemNumber) {
    problemHeader(problemNumber, "Linked Lists (read)");
    
    Vector<int> v {1, 2, 4, 3, 5, 7, 11, 0, 6, 1, 1};
    ListNode* front = vectorToList(v);

    linkedListMystery2(front);
    
    printChain(front, "front");
    problemFooter();
}
