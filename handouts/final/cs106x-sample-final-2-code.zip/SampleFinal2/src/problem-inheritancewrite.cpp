#include <iomanip>
#include "problems.h"
#include "inheritance-superclass.h"
#include "hashmap.h"
#include "hashset.h"
#include "map.h"
#include "set.h"
#include "vector.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// MemoryCalculator.h
class MemoryCalculator : public Calculator {
public:
    MemoryCalculator(int seed);
    virtual int kthPrime(int k);
    virtual int getComputeCount() const;
    virtual int getMemoCount() const;
    bool operator ==(const MemoryCalculator& mc2) const;
    bool operator !=(const MemoryCalculator& mc2) const;
    
private:
    Map<int, int> primes;
    int memoCount;
};


// MemoryCalculator.cpp
MemoryCalculator::MemoryCalculator(int seed)
        : Calculator(seed) {
    memoCount = 0;
}

int MemoryCalculator::kthPrime(int k) {
    if (primes.containsKey(k)) {
        memoCount++;
        return primes[k];
    } else {
        int kth = Calculator::kthPrime(k);
        primes[k] = kth;
        return kth;
    }
}

int MemoryCalculator::getComputeCount() const {
    return primes.size();
}

int MemoryCalculator::getMemoCount() const {
    return memoCount;
}

bool MemoryCalculator::operator ==(const MemoryCalculator& mc2) const {
    return getSeed() == mc2.getSeed()
            && getComputeCount() == mc2.getComputeCount()
            && getMemoCount() == mc2.getMemoCount()
            && primes == mc2.primes;
}

bool MemoryCalculator::operator !=(const MemoryCalculator& mc2) const {
    return !(*this == mc2);
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void test_inheritanceWrite(int problemNumber) {
    problemHeader(problemNumber, "Inheritance/OOP (write)");

    MemoryCalculator calc(106);
    cout << "getSeed() = " << calc.getSeed() << endl;
    cout << "kthPrime(17) = " << calc.kthPrime(17) << endl;
    cout << "kthPrime(17) = " << calc.kthPrime(17) << endl;
    cout << "kthPrime(17) = " << calc.kthPrime(17) << endl;
    cout << "kthPrime(17) = " << calc.kthPrime(17) << endl;

    cout << "getComputeCount() = " << calc.getComputeCount() << endl;
    cout << "getMemoCount()    = " << calc.getMemoCount() << endl;
    cout << "actual kth calls  = " << calc.getKthPrimeCalls() << endl;
            
    cout << "kthPrime(4)  = " << calc.kthPrime(4) << endl;
    cout << "kthPrime(2)  = " << calc.kthPrime(2) << endl;
    cout << "kthPrime(2)  = " << calc.kthPrime(2) << endl;
    cout << "kthPrime(17) = " << calc.kthPrime(17) << endl;
    cout << "kthPrime(2)  = " << calc.kthPrime(2) << endl;
    cout << "kthPrime(4)  = " << calc.kthPrime(4) << endl;
    
    cout << "getComputeCount() = " << calc.getComputeCount() << endl;
    cout << "getMemoCount()    = " << calc.getMemoCount() << endl;
    cout << "actual kth calls  = " << calc.getKthPrimeCalls() << endl;
    cout << endl;
    
    for (int i = 1; i <= 200; i++) {
        cout << "kthPrime(" << i << ")  = " << calc.kthPrime(i) << endl;
    }
    cout << "getComputeCount() = " << calc.getComputeCount() << endl;
    cout << "getMemoCount()    = " << calc.getMemoCount() << endl;
    cout << "actual kth calls  = " << calc.getKthPrimeCalls() << endl;
    
    for (int i = 1; i <= 200; i++) {
        calc.kthPrime(i);
    }
    cout << "getComputeCount() = " << calc.getComputeCount() << endl;
    cout << "getMemoCount()    = " << calc.getMemoCount() << endl;
    cout << "actual kth calls  = " << calc.getKthPrimeCalls() << endl;
    cout << endl;
    
    problemFooter();
}

