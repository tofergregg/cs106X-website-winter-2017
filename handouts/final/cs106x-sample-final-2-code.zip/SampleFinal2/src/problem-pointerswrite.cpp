#include "problems.h"

extern void printChain(ListNode* list, string name, int maxLength = 20);

void test_pointersWrite(int problemNumber) {
    problemHeader(problemNumber, "Pointers (write)");
    
    ListNode* list1 = new ListNode(1, new ListNode(2));
    ListNode* list2 = new ListNode(3, new ListNode(4, new ListNode(5)));

    // ============================================================================
    // || YOUR SOLUTION CODE GOES BELOW
    // ============================================================================
    
    ListNode* temp = list1->next;
    list1->next = list2->next->next;       // 1 -> 5
    list2->next->next = list1;             // 4 -> 1
    temp->next = list2->next;              // 2 -> 4
    list2->next = temp;                    // 3 -> 2
    list1 = list2;
    
    // ============================================================================
    // || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
    // ============================================================================

    // print the lists
    printChain(list1, "list1");
    // printChain(temp, "temp");
    cout << endl;
}
