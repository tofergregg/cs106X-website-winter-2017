#include "problems.h"

#include <iostream>
#include <string>
using namespace std;

void makeTreeSetFromString(TreeSet<string>& set, string s) {
    Vector<string> tokens = stringSplit(s, ", ");
    for (string token : tokens) {
        set.add(token);
    }
}

void printTraversals(TreeSet<string>& set) {
    cout << "pre-order:  ";
    set.print(PRE_ORDER);
    cout << "in-order:   ";
    set.print(IN_ORDER);
    cout << "post-order: ";
    set.print(POST_ORDER);
    cout << "-----" << endl;
}

void test_binarySearchTreesRead(int problemNumber) {
    problemHeader(problemNumber, "Binary Search Trees (read)");
    
    TreeSet<string> set;
    makeTreeSetFromString(set, "Cersei, Arya, Jamie, Littlefinger, Danaerys, Tyrion, Ned, Stannis, Varys, Ramsay, Bran, Hodor");
    
    cout << "(a)" << endl;
    set.printSideways();
    cout << "-----" << endl;
    
    cout << "(b)" << endl;
    // printTraversals(set);
    bool balanced = set.isBalanced();
    cout << "isBalanced? " << boolalpha << balanced << endl;
    
    Vector<string> toRemove = stringSplit("Littlefinger, Cersei, Jamie", ", ");
    for (string s : toRemove) {
        set.remove(s);
    }
    cout << "(c)" << endl;
    set.printSideways();
    
    problemFooter();
}
