#include "problems.h"

#include <iostream>
using namespace std;

// order: K -> C -> (R, E)

class Kain {
public:
    virtual void m1() {
        cout << "Kain m1" << endl;
    }

    virtual void m2() {
        m1();
        cout << "Kain m2" << endl;
    }
};

class Cecil : public Kain {
public:
    virtual void m1() {
        cout << "Cecil m1" << endl;
        Kain::m1();
    }

    virtual void m3() {
        cout << "Cecil m3" << endl;
        m2();
    }
};

class Rosa : public Cecil {
public:
    virtual void m3() {
        cout << "Rosa m3" << endl;
        m2();
    }
    
    virtual void m4() {
        cout << "Rosa m4" << endl;
    }
};

class Golbez : public Cecil {
public:
    virtual void m2() {
        cout << "Golbez m2" << endl;
        m1();
    }
};

void test_inheritanceRead(int problemNumber) {
    problemHeader(problemNumber, "Inheritance/Polymorphism (read)");

    Kain*  var1 = new Cecil();
    Cecil* var2 = new Rosa();
    Kain*  var3 = new Golbez();
    Cecil* var4 = new Golbez();

    POLYM(var1->m1());
    POLYM(var1->m2());
    POLYC(var1->m3());
    POLYM(var2->m3());
    POLYM(var3->m2());
    POLYC(var3->m4());
    POLYM(var4->m3());
    POLYM( ((Cecil*) var1)->m3() );
    POLYR( ((Rosa*) var1)->m4() );
    POLYM( ((Rosa*) var2)->m4() );
    POLYC( ((Golbez*) var3)->m4() );
    
    problemFooter();
}
