#include <cmath>
#include <iostream>
#include <sstream>
#include "PriorityQueue.h"
#include "error.h"

int PriorityQueue::nodesAtLevel(int level) {
    if (level <= 0) {
        throw level;
    }
    int start = 1;
    for (int i = 1; i <= level - 1; i++) {
        start = start * 2;  // go to leftmost child at the given level
    }
    if (start > m_size) {
        throw level;
    }

    int end = min(m_size + 1, 2 * start);
    return end - start;
}

int PriorityQueue::nodesAtLevel2(int n) {
    int start = (int) pow(2, n - 1);
    if (n < 1 || m_size < start) {
        throw n;
    }
    int end = min(start * 2, m_size + 1);
    return end - start;
}

PriorityQueue::PriorityQueue() {
    m_size = 0;
    m_capacity = 10;
    m_elements = new PQNode[m_capacity];
}

PriorityQueue::~PriorityQueue() {
    delete[] m_elements;
}

void PriorityQueue::enqueue(int value, double priority) {

}

int PriorityQueue::dequeue() {
    return -1;
}

int PriorityQueue::peek() const {
    if (isEmpty()) {
        error("Cannot peek an empty queue");
    }
    return m_elements[1].data;
}

int PriorityQueue::size() const {
    return m_size;
}

bool PriorityQueue::isEmpty() const {
    return size() == 0;
}

string PriorityQueue::toString() const {
    ostringstream out;
    out << "{";
    if (!isEmpty()) {
        out << m_elements[0].data << ":" << m_elements[0].priority;
        for (int i = 1; i <= m_size; i++) {
            out << ", " << m_elements[i].data << ":" << m_elements[i].priority;
        }
    }
    out << "}";
    return out.str();
}

void PriorityQueue::resize() {
    PQNode* newElements = new PQNode[2 * m_capacity];
    for (int i = 1; i <= m_size; i++) {
        newElements[i] = m_elements[i];
    }
    delete[] m_elements;
    m_elements = newElements;
    m_capacity *= 2;
}

int PriorityQueue::parent(int index) const {
    return index / 2;
}

int PriorityQueue::left(int index) const {
    return index * 2;
}

int PriorityQueue::right(int index) const {
    return left(index) + 1;
}

bool PriorityQueue::hasParent(int index) const {
    return index > 1;
}

bool PriorityQueue::hasLeft(int index) const {
    return left(index) <= m_size;
}

bool PriorityQueue::hasRight(int index) const {
    return right(index) <= m_size;
}

void PriorityQueue::swap(PQNode* array, int i1, int i2) {
    PQNode temp = array[i1];
    array[i1] = array[i2];
    array[i2] = temp;
}
