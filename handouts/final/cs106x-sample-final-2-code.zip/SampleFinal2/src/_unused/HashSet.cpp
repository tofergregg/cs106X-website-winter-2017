/*
 * CS 106B, Autumn 2013, Marty Stepp
 * This file contains the implementation of the HashSet class, which implements
 * a set of integers using a hash table.
 * See HashSet.h for the declarations of each member.
 */

#include <iostream>
#include <iomanip>
#include "HashSet.h"
using namespace std;

// solution 1: no special case for k <= 0; while loop to remove
//void HashSet::trimChains(int k) {
//    for (int i = 0; i < m_capacity; i++) {
//        int length = 0;
//        HashNode* current = m_elements[i];
//        while (current != NULL) {                     // count length of chain
//            length++;
//            current = current->next;
//        }
//        while (length > k && m_elements[i] != NULL) {   // remove nodes from front
//            HashNode* trash = m_elements[i];
//            m_elements[i] = m_elements[i]->next;
//            delete trash;
//            length--;
//            m_size--;
//        }
//    }
//}

// solution 2: special-case k <= 0; for loop to remove
void HashSet::trimChains(int k) {
    if (k <= 0) {
        for (int i = 0; i < m_capacity; i++) {
            m_elements[i] = NULL;
        }
        m_size = 0;
    } else {
        for (int i = 0; i < m_capacity; i++) {
            int length = 0;
            HashNode* current = m_elements[i];
            while (current != NULL) {
                length++;
                current = current->next;
            }

            if (length > k) {
                int numToRemove = length - k;
                current = m_elements[i];
                for (int j = 0; j < numToRemove; j++) {
                    HashNode* trash = current;
                    current = current->next;
                    delete trash;
                }
                m_elements[i] = current;
                m_size -= numToRemove;
            }
        }
    }
}



HashSet::HashSet() {
    m_size = 0;
    m_capacity = 10;
    m_elements = new HashNode*[m_capacity]();   // all null
}

void HashSet::add(int value) {
    if (!contains(value)) {
        int index = hashCode(value);
        HashNode* node = new HashNode(value);
        node->next = m_elements[index];
        m_elements[index] = node;
        m_size++;
    }
}

bool HashSet::contains(int value) const {
    int index = hashCode(value);
    HashNode* current = m_elements[index];
    while (current != NULL) {
        if (current->data == value) {
            return true;
        }
        current = current->next;
    }
    return false;
}

int HashSet::hashCode(int value) const {
    return abs(value) % m_capacity;
}

void HashSet::remove(int value) {
    // not implemented
}

void HashSet::printStructure() const {
    for (int i = 0; i < m_capacity; i++) {
        cout << "[" << setw(2) << i << "]:";
        HashNode* curr = m_elements[i];
        while (curr != NULL) {
            cout << " -> " << setw(2) << curr->data;
            curr = curr->next;
        }
        cout << " /" << endl;
    }
    // cout << "size = " << m_size << ", load factor = " << loadFactor() << endl;
}
