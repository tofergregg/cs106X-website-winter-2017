#ifndef _timer_h
#define _timer_h

class Timer {
private:
    long m_startMS;
    long m_stopMS;
    bool m_isStarted;

public:
    Timer();
    long getElapsed() const;
    bool isStarted() const;
    void start();
    long stop();
};

#endif // _timer_h
