#ifndef _priorityqueue_h
#define _priorityqueue_h

using namespace std;

struct PQNode {
    int data;
    double priority;
    PQNode(int data = 0, double priority = 0.0) {
        this->data = data;
        this->priority = priority;
    }
};

class PriorityQueue {
public:
    PriorityQueue();
    ~PriorityQueue();
    void enqueue(int value, double priority);
    int dequeue();
    int peek() const;
    int size() const;
    bool isEmpty() const;
    string toString() const;

    int nodesAtLevel(int level);
    int nodesAtLevel2(int level);

private:
    PQNode* m_elements;
    int m_capacity;
    int m_size;

    // helpers that are already written
    int parent(int index) const;
    int left(int index) const;
    int right(int index) const;
    bool hasParent(int index) const;
    bool hasLeft(int index) const;
    bool hasRight(int index) const;

    void swap(PQNode* array, int i1, int i2);
    void resize();
};

#endif
