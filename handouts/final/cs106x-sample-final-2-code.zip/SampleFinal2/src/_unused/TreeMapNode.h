/*
 * CS 106B, Autumn 2013, Marty Stepp
 * This file contains the declaration of the TreeMapNode structure.
 * A TreeMapNode stores one string/integer key/value pair in a tree map.
 */

#ifndef _treemapnode_h
#define _treemapnode_h

#include <string>
using namespace std;

struct TreeMapNode {
    string key;
    int value;
    TreeMapNode* left;
    TreeMapNode* right;

    /*
     * Constructs a new tree node with the given key/value and left/right links.
     */
    TreeMapNode(string key, int value, TreeMapNode* left = NULL, TreeMapNode* right = NULL) {
        this->key = key;
        this->value = value;
        this->left = left;
        this->right = right;
    }
    
    /*
     * Returns true if this node has no children.
     */
    bool isLeaf() {
        return left == NULL && right == NULL;
    }
};

#endif
