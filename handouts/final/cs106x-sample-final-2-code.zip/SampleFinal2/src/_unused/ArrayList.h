/*
 * CS 106B, Autumn 2013, Marty Stepp
 * ArrayList is our example of implementing a basic data structure.
 * This initial version of the ArrayList is missing some important features.
 * For example, if the array fills up to its capacity, the list runs out of space,
 * and the various member functions don't check indexes to see if they are out
 * of bounds.  Also the list can store only ints.  We will address these issues later.
 */

#ifndef _arraylist_h
#define _arraylist_h

#include <fstream>
#include <iostream>
#include <string>

using namespace std;

/*
 * An ArrayList is an ordered collection of integers stored and accessed
 * with 0-based integer indexes, using an array as the internal representation.
 */
class ArrayList {
public:
    /*
     * Constructs a new empty list.
     */
    ArrayList();
    
    /*
     * This destructor frees the memory that was allocated internally by the list.
     */
    ~ArrayList();

    /*
     * Appends the given value to the end of the list.
     */
    void add(int value);

    /*
     * Removes all values from the list.
     */
    void clear();

    /*
     * Returns the value at the given 0-based index of the list.
     */
    int get(int index);

    /*
     * Adds the given value just before the given 0-based index in the list,
     * shifting subsequent elements right as necessary to make room.
     */
    void insert(int index, int value);

    /*
     * Returns true if there are no elements in the list.
     */
    bool isEmpty();

    /*
     * Removes the element at the given 0-based index from the list,
     * shifting subsequent elements left as necessary to cover its slot.
     */
    void remove(int index);

    /*
     * Stores the given value at the given 0-based index in the list.
     */
    void set(int index, int value);

    /*
     * Returns the number of elements in the list.
     */
    int size();

    /*
     * Returns a string representation of the list such as "[42, 3, 17]".
     */
    string toString();

private:
    // member variables inside each list object;
    // we precede them with "m_" just as a stylistic convention
    // to make them easier to identify in the .cpp code

    int* m_elements;   // array of elements
    int m_capacity;    // length of array
    int m_size;        // number of elements added
    
    /*
     * This private helper resizes the list's internal array buffer if necessary
     * to accommodate additional elements.
     */
    void checkResize();

    /*
     * This helper throws a string exception if the given index is not between
     * the given min/max indexes, inclusive.
     */
    void checkIndex(int index, int min, int max);
};

#endif









