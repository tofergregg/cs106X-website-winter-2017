#include <sys/time.h>
#include "Timer.h"

Timer::Timer() {
    this->m_startMS = 0;
    this->m_stopMS = 0;
    this->m_isStarted = false;
}

long Timer::getElapsed() const {
    return this->m_stopMS - this->m_startMS;
}

bool Timer::isStarted() const {
    return m_isStarted;
}

void Timer::start() {
    timeval time;
    gettimeofday(&time, 0);
    this->m_startMS = (time.tv_sec * 1000000 + time.tv_usec) / 1000;
    this->m_isStarted = true;
}

long Timer::stop() {
    if (!this->m_isStarted) {
        throw "Timer is not started";
    }
    timeval time;
    gettimeofday(&time, 0);
    this->m_stopMS = (time.tv_sec * 1000000 + time.tv_usec) / 1000;
    this->m_isStarted = false;
    return getElapsed();
}
