/*
 * CS 106B, Autumn 2013, Marty Stepp
 * ArrayList.cpp implements the ArrayList class behavior declared in ArrayList.h.
 *
 * Today's version is able to resize the array to grow it as needed if it
 * becomes full.  It also throws exceptions when you pass invalid index parameters.
 */

#include <string>
#include "ArrayList.h"
#include "strlib.h"
#include "error.h"

using namespace std;

ArrayList::ArrayList() {
    m_size = 0;
    m_capacity = 10;
    m_elements = new int[m_capacity];
}

ArrayList::~ArrayList() {
    delete[] m_elements;
}

void ArrayList::add(int value) {
    checkResize();
    m_elements[m_size] = value;
    m_size++;
}

void ArrayList::clear() {
    m_size = 0;
}

int ArrayList::get(int index) {
    checkIndex(index, 0, m_size);
    return m_elements[index];
}

void ArrayList::insert(int index, int value) {
    checkIndex(index, 0, m_size);  // index of m_size is allowed (appends at end)
    checkResize();

    // shift right to make room
    for (int i = m_size; i > index; i--) {
        m_elements[i] = m_elements[i - 1];
    }
    m_elements[index] = value;
    m_size++;
}

bool ArrayList::isEmpty() {
    return m_size == 0;
}

void ArrayList::remove(int index) {
    checkIndex(index, 0, m_size - 1);
    for (int i = index; i < m_size; i++) {
        m_elements[i] = m_elements[i + 1];
    }
    m_size--;
}

void ArrayList::set(int index, int value) {
    checkIndex(index, 0, m_size - 1);
    m_elements[index] = value;
}

int ArrayList::size() {
    return m_size;
}

string ArrayList::toString() {
    string s = "[";
    if (!isEmpty()) {
        s += integerToString(m_elements[0]);
        for (int i = 1; i < m_size; i++) {
            s += ", ";
            s += integerToString(m_elements[i]);
        }
    }
    s += "]";
    return s;
}

void ArrayList::checkIndex(int index, int min, int max) {
    if (index < min || index > max) {
        throw string("Invalid index");
    }
}

void ArrayList::checkResize() {
    if (m_size == m_capacity) {
        // out of space; resize
        int* bigDaddy = new int[m_capacity * 2];
        for (int i = 0; i < m_size; i++) {
            bigDaddy[i] = m_elements[i];
        }
        delete[] m_elements;   // free old array's memory
        m_elements = bigDaddy;
        m_capacity *= 2;
    }
}
