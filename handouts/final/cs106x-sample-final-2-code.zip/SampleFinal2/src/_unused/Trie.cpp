/*
 * CS 106B, Autumn 2013, Marty Stepp
 * This file contains the implementation of the Trie class, which represents
 * a prefix tree set of strings.
 * See Trie.h for the declarations of the members.
 *
 * The implementations of the recursive helpers are a bit redundant;
 * we could combine the contains helpers at least.
 * But this is left out for now.
 */

#include <sstream>
#include "Trie.h"
#include "strlib.h"

Trie::Trie() {
    m_root = NULL;
    m_size = 0;
}

Trie::~Trie() {
    // TODO: free memory for the tree

}

void Trie::add(string word) {
    add(m_root, word);
}

void Trie::add(TrieNode*& node, string word) {
    if (node == NULL) {
        // create nodes all the way down, one for each letter of the word
        node = new TrieNode();
    }
    
    if (word.length() == 0) {
        // base case: we have added all of the letters of this word
        node->isWord = true;
    } else {
        char c = tolower(word[0]);
        int index = c - 'a';
        add(node->children[index], word.substr(1));
    }
}

bool Trie::contains(string word) const {
    return contains(m_root, word);
}

bool Trie::contains(TrieNode* node, string word) const {
    if (node == NULL) {
        // base case: no pointer down to here, so prefix must not exist
        return false;
    } else if (word.length() == 0) {
        // base case: found nodes all the way down, just make sure this exact
        // word was added in the past
        return node->isWord;
    } else {
        // recursive case: follow appropriate child pointer for one letter
        char c = tolower(word[0]);
        int index = c - 'a';
        return contains(node->children[index], word.substr(1));
    }
}

bool Trie::containsPrefix(string word) const {
    return containsPrefix(m_root, word);
}

bool Trie::containsPrefix(TrieNode* node, string word) const {
    if (node == NULL) {
        // base case: no pointer down to here, so prefix must not exist
        return false;
    } else if (word.length() == 0) {
        // base case: found nodes all the way down, so the prefix exists
        return true;
    } else {
        // recursive case: follow appropriate child pointer for one letter
        char c = tolower(word[0]);
        int index = c - 'a';
        return containsPrefix(node->children[index], word.substr(1));
    }
}
