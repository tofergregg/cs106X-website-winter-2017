/*
 * CS 106B/X, Marty Stepp
 * 
 * This program runs all of the various tests on each problem.
 * If you want to type in your solution to a given problem, open the problemXX.cpp
 * file for that problem and type your solution there.
 */

#include <iostream>
#include "console.h"
#include "problems.h"
using namespace std;

int main() {
    test_arrayListsWrite(1);
    test_linkedListsRead(2);
    test_linkedListsWrite(3);
    test_binarySearchTreesRead(4);
    test_binaryTreesWrite(5);
    test_graphsWrite(6);
    test_hashingRead(7);
    test_inheritanceRead(8);
    test_inheritanceWrite(9);

    cout << "All tests completed." << endl;
    return 0;
}

void problemHeader(int number, string title) {
    cout << endl << endl;
    cout << "Problem " << setw(2) << number << ": " << title << endl;
    cout << "---------------------------------------------" << endl;
}

void problemFooter() {
    cout << "---------------------------------------------" << endl;
}
