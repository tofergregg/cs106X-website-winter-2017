#include "problems.h"
#include "searchingsorting.h"

#include <iostream>
using namespace std;

void test_searchingAndSortingRead(int problemNumber) {
    problemHeader(problemNumber, "Searching and Sorting (read)");

    cout << "(no code provided)" << endl;

    problemFooter();
}
