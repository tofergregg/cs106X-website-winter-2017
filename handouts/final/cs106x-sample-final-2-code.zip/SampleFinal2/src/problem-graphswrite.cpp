#include "problems.h"
#include <iostream>
#include <sstream>
#include "basicgraph.h"
#include "graphsupport.h"
#include "simpio.h"
#include "vector.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

void findLongestPathHelper(BasicGraph& graph, Vector<Vertex*>& chosen,
                                              Vector<Vertex*>& longest, Vertex* start) {
    // "choose" this vertex  (mark as visited and add to path so far)
    start->visited = true;
    chosen.add(start);
    
    // remember what is the longest path we have seen so far
    if (chosen.size() > longest.size()) {
        longest = chosen;
    }
    
    // for each neighbor, explore
    for (Vertex* neighbor : graph.getNeighbors(start)) {
        if (!neighbor->visited) {
            findLongestPathHelper(graph, chosen, longest, neighbor);
        }
    }
    
    // "un-choose" this vertex  (un-mark and remove from path so far)
    start->visited = false;
    chosen.remove(chosen.size() - 1);
}

Vector<Vertex*> findLongestPath(BasicGraph& graph) {
    Vector<Vertex*> longest;
    if (graph.getEdgeSet().isEmpty()) {
        return longest;
    }
    
    graph.resetData();
    Vector<Vertex*> chosen;

    // try to find longest path from every possible starting vertex
    for (Vertex* v : graph.getVertexSet()) {
        findLongestPathHelper(graph, chosen, longest, v);
    }
    return longest;
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void readPath(BasicGraph& graph, string pathStr, Vector<Vertex*>& vpath);
void testGraph(string graphStr);

void test_graphsWrite(int problemNumber) {
    problemHeader(problemNumber, "Graphs (write)");

    string graph1 = "{A, B, C, D, E, F, G, H, A -> B, A -> C, A -> D, A -> E, B -> C, D -> G, F -> A, F -> C, F -> D, F -> E, G -> E, G -> H, H -> C, H -> E, H -> F}";
    testGraph(graph1);
    
    string graph2 = "{A, B, C}";
    testGraph(graph2);
    
    string empty = "{}";
    testGraph(empty);

    problemFooter();
}

void testGraph(string graphStr) {
    BasicGraph graph;
    istringstream input(graphStr);
    input >> graph;
    cout << "graph: " << graph << endl;
    try {
        Vector<Vertex*> path = findLongestPath(graph);
        cout << "  findLongestPath() returned: ";
        printPath(path);
    } catch (...) {
        cout << "(threw exception!)" << endl;
    }
}

string printSet(Set<Vertex*>& set) {
    ostringstream out;
    out << "{";
    int first = true;
    for (Vertex* v : set) {
        if (!first) {
            out << ", ";
        }
        first = false;
        out << v->name;
    }
    out << "}";
    return out.str();
}

void readPath(BasicGraph& graph, string pathStr, Vector<Vertex*>& vpath) {
    Vector<string> vpathStr;
    istringstream input(pathStr);
    input >> vpathStr;
    for (string vstr : vpathStr) {
        if (graph.containsVertex(vstr)) {
            vpath.add(graph.getVertex(vstr));
        } else {
            Vertex* dummy = new Vertex(vstr);     // not in graph
            vpath.add(dummy);
        }
    }
}
