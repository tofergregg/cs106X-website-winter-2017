#include "problems.h"
#include "HeapPriorityQueue.h"

#include <iostream>
using namespace std;

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1
int HeapPriorityQueue::atLevel(int level) const {
    if (level <= 0) {
        throw level;
    }
    
    int start = 1;
    for (int i = 1; i <= level - 1; i++) {
        start = start * 2; // go to leftmost child at the given level
    }
    if (start > mysize) {
        throw level;
    }
    int end = min(mysize + 1, 2 * start);
    return end - start;
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void test_heapsWrite(int problemNumber) {
    problemHeader(problemNumber, "Heaps (write)");

    string elementsToAdd = "hi:-9, ok:-4, bye:2, you:33, me:5, who:32, us:22, why:39, oh:34, do:14";
    HeapPriorityQueue pq;
    stringToPQ(pq, elementsToAdd);
    cout << pq << endl;
    
    for (int i = 0; i <= 5; i++) {
        cout << "atLevel(" << i << ") = ";
        try {
            int result = pq.atLevel(i);
            cout << result << endl;
        } catch (...) {
            cout << "(threw exception)" << endl;
        }
    }

    problemFooter();
}
