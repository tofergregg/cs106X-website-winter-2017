#include "problems.h"

#include <iostream>
using namespace std;

// K -> C -> (R, E)

class Kurt {
public:
    virtual void a() {
        cout << "Kurt A" << endl;
        c();
    }

    virtual void c() {
        cout << "Kurt C" << endl;
    }
};

class Eddie : public Kurt {
public:
    virtual void b() {
        a();
        cout << "Eddie B" << endl;
    }

    virtual void c() {
        cout << "Eddie C" << endl;
    }
};

class Jerry : public Kurt {
public:
    virtual void a() {
        cout << "Jerry A" << endl;
    }

    virtual void c() {
        cout << "Jerry C" << endl;
        Kurt::c();
    }
};

class Chris : public Jerry {
public:
    virtual void b() {
        a();
        cout << "Chris B" << endl;
    }

    virtual void c() {
        cout << "Chris C" << endl;
        Jerry::c();
    }

    virtual void d() {
        cout << "Chris D" << endl;
        c();
    }
};


#define POLYM(stmt) \
  { cout << #stmt << ";" << endl; stmt; cout << endl; }

#define POLYC(stmt) \
  { cout << #stmt << ":" << endl; cout << "COMPILER ERROR" << endl << endl; }

#define POLYR(stmt) \
  { cout << #stmt << ":" << endl; cout << "CRASH / RUNTIME ERROR" << endl << endl; }


void test_inheritanceRead(int problemNumber) {
    problemHeader(problemNumber, "Inheritance (read)");

    Kurt*  var1 = new Jerry();
    Jerry* var2 = new Chris();
    Kurt*  var3 = new Eddie();
    Kurt*  var4 = new Chris();
    Kurt*  var5 = new Kurt();

    POLYM( var1->a() );
    POLYC( var1->b() );
    POLYM( var1->c() );
    POLYM( var2->a() );
    POLYC( var2->b() );
    POLYM( var2->c() );
    POLYM( var3->a() );
    POLYC( var3->b() );
    POLYM( var4->a() );
    POLYM( var5->a() );
    POLYM( ((Jerry*) var1)->a() );
    POLYC( ((Jerry*) var1)->b() );
    POLYM( ((Chris*) var2)->d() );
    POLYM( ((Eddie*) var3)->b() );
    POLYM( ((Jerry*) var4)->a() );
    POLYC( ((Jerry*) var4)->b() );
    POLYC( ((Jerry*) var5)->b() );
    
    problemFooter();
}
// L -> B -> H -> M
// order: H B M L

