#include "problems.h"

#include <iostream>
#include <string>
#include "BinaryTree.h"
using namespace std;

void test_binarySearchTreesRead(int problemNumber) {
    problemHeader(problemNumber, "Binary Search Trees (read)");
    
    Vector<string> v {"Dodo", "Eaglet", "Rabbit", "Cat", "Alice", "Jabberwock", "Hatter", "Tweedledee", "Queen", "Bill"};
    
    TreeSet<string> set;
    for (string s : v) {
        set.add(s);
    }
    
    cout << "(a)" << endl;
    set.printSideways();
    cout << "-----" << endl;
    
    cout << "(b)" << endl;
    cout << "pre-order:  ";
    set.print(PRE_ORDER);
    cout << "in-order:   ";
    set.print(IN_ORDER);
    cout << "post-order: ";
    set.print(POST_ORDER);
    cout << "-----" << endl;
    
    Vector<string> toRemove {"Hatter", "Cat", "Rabbit", "Dodo"};
    for (string s : toRemove) {
        set.remove(s);
    }
    cout << "(c)" << endl;
    set.printSideways();
    
    problemFooter();
}
