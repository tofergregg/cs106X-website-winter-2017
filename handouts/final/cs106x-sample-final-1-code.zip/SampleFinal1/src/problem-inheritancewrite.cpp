#include <iomanip>
#include "problems.h"
#include "inheritance-superclass.h"
#include "hashmap.h"
#include "hashset.h"
#include "map.h"
#include "set.h"
#include "vector.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// RiggedDice.h
class RiggedDice : public Dice {
public:
    RiggedDice(int count, int min);
    int getMin() const;
    void roll(int index);
    int total() const;
    string toString() const;

private:
    int min;
};

bool operator <(const RiggedDice& rig1, const RiggedDice& rig2);


// RiggedDice.cpp
RiggedDice::RiggedDice(int count, int min) : Dice(count) {
    if (min < 0 || min >= 6) {
        throw min;
    }
    this->min = min;
}

int RiggedDice::getMin() const {
    return min;
}

void RiggedDice::roll(int index) {
    Dice::roll(index);
    while (getValue(index) < min) {    // do/while is okay
        Dice::roll(index);
    }
}

int RiggedDice::total() const {
    return Dice::total() + 1;
}

string RiggedDice::toString() const {
    return string("rigged ") + Dice::toString() + " min " + integerToString(min);
}

bool operator <(const RiggedDice& rig1, const RiggedDice& rig2) {
    int myTotal = rig1.total();
    int hisTotal = rig2.total();
    if (myTotal != hisTotal) {
        return myTotal < hisTotal;
    } else {
        return rig1.getMin() < rig2.getMin();
    }
}


// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void test_inheritanceWrite(int problemNumber) {
    problemHeader(problemNumber, "Inheritance/OOP (write)");

    RiggedDice rigged(4, 3);
    cout << "getCount: " << rigged.getCount() << endl;
    cout << "getMin:   " << rigged.getMin() << endl;
    cout << "roll:" << endl;
    for (int i = 0; i < rigged.getCount(); i++) {
        rigged.roll(i);
        cout << "  getValue(" << i << "): " << rigged.getValue(i) << endl;
    }
    cout << "total:    " << rigged.total() << endl;
    cout << "toString: " << rigged.toString() << endl;

    problemFooter();
}

