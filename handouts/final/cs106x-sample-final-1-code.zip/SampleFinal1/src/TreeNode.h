/*
 * CS 106B, Marty Stepp
 * This file contains the declaration of the TreeNode structure.
 * A TreeNode stores one integer piece of data in a binary tree of integers.
 */

#ifndef _treenode_h
#define _treenode_h

#include <cstdlib>

struct TreeNode {
public:
    static int s_freed;
    int data;
    TreeNode* left;
    TreeNode* right;

    /*
     * Constructs a new tree node with the given data and left/right links.
     */
    TreeNode(int data = 0, TreeNode* left = NULL, TreeNode* right = NULL);
    ~TreeNode();
    bool isLeaf();
};

#endif
