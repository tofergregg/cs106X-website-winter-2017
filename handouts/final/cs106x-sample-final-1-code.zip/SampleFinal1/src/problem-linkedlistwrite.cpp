#include "problems.h"
#include "ListNode.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1: build entirely new chain, then swap it in
void expand(ListNode*& front, int k) {
    if (k < 0) {
        throw k;
    } else if (front == nullptr) {
        return;
    } else if (k == 0) {
        // clear out list contents
        while (front) {
            ListNode* trash = front;
            front = front->next;
            delete trash;
        }
    } else {
        // replicate front node
        ListNode* front2 = new ListNode(front->data / k);
        ListNode* curr2 = front2;
        for (int i = 0; i < k - 1; i++) {
            curr2->next = new ListNode(front->data / k);
            curr2 = curr2->next;
        }

        // replicate other nodes
        ListNode* curr = front->next;
        delete front;
        while (curr != nullptr) {
            for (int i = 0; i < k; i++) {
                curr2->next = new ListNode(curr->data / k);
                curr2 = curr2->next;
            }
            ListNode* trash = curr;
            curr = curr->next;
            delete trash;
        }

        front = front2;
    }
}


// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void printChain(ListNode* list, string name, int maxLength = 20) {
    cout << name << " -> ";
    ListNode* curr = list;
    bool cycle = false;
    for (int i = 0; curr != nullptr && i < maxLength; i++, curr = curr->next) {
        cout << "[" << curr->data << "]";
        if (curr->next != nullptr) {
            cout << " -> ";
        }
        if (i == maxLength - 1) {
            cycle = true;
            cout << " ... (cycle)";
        }
    }
    if (!cycle) {
        cout << " /";
    }
    cout << endl;
}

ListNode* vectorToList(Vector<int>& v) {
    ListNode* front = nullptr;
    ListNode* curr = nullptr;
    while (!v.isEmpty()) {
        int n = v[0];
        v.remove(0);
        if (!curr) {
            front = new ListNode(n);
            curr = front;
        } else {
            curr->next = new ListNode(n);
            curr = curr->next;
        }
    }
    return front;
}

void testList(Vector<int> v, int k, bool catchExceptions = true) {
    ListNode* front = vectorToList(v);
    cout << endl;
    cout << "before expand(" << k << "): " << endl;
    printChain(front, "front");
    cout << "nodes freed=" << setw(2) << ListNode::s_freed << endl;
    if (catchExceptions) {
        try {
            expand(front, k);
        } catch (string s) {
            cout << "threw a string exception: " << s << endl;
        } catch (const char* s) {
            cout << "threw a string exception: " << s << endl;
        } catch (int n) {
            cout << "threw an integer exception: " << n << endl;
        } catch (...) {
            cout << "threw an exception." << endl;
        }
    } else {
        // just call it without try/catch
        expand(front, k);
    }

    cout << "after:" << endl;
    printChain(front, "front");
    cout << "nodes freed=" << setw(2) << ListNode::s_freed << endl;
}

void test_linkedListsWrite(int problemNumber) {
    problemHeader(problemNumber, "Linked Lists (write)");

    Vector<int> v {12, 34, -8, 3, 46};
    testList(v, 2);
    testList(v, 3);
    testList(v, 5);
    testList(v, 0);

    try {
        testList(v, -1, /* catchExceptions */ false);
        cout << "didn't throw exception (bad!)" << endl;
    } catch (...) {
        cout << "threw exception (good!)" << endl;
    }

    problemFooter();
}
