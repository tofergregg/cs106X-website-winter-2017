#include "problems.h"
#include "HeapPriorityQueue.h"
#include "strlib.h"
#include "vector.h"
#include <iostream>
using namespace std;

void test_heapsRead(int problemNumber) {
    problemHeader(problemNumber, "Heaps (read)");

    string elementsToAdd = "a:17, b:63, c:40, d:95, e:13, f:10, g:12, h:43, i:47, j:15, l:82";
    int NUM_REMOVES = 2;
    
    HeapPriorityQueue pq;
    stringToPQ(pq, elementsToAdd);
    
    cout << "(a)" << endl;
    cout << pq << endl;
    pq.printSideways();
    cout << "-----" << endl;
    
    cout << "(b)" << endl;
    for (int i = 0; i < NUM_REMOVES; i++) {
        pq.dequeue();
    }
    cout << pq << endl;
    pq.printSideways();

    problemFooter();
}

