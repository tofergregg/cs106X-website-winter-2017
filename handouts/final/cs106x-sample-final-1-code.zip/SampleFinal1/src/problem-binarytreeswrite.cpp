#include "problems.h"
#include "TreeNode.h"
#include "BinaryTree.h"

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1: counting up (passing current level)
void swapChildrenAtLevelHelper(TreeNode* node, int k, int currentLevel);

void swapChildrenAtLevel(TreeNode*& node, int k) {
    if (k <= 0) {
        throw k;
    }
    swapChildrenAtLevelHelper(node, k, 1);
}

void swapChildrenAtLevelHelper(TreeNode* node, int k, int currentLevel) {
    if (node != NULL) {
        if (currentLevel == k) {
            TreeNode* temp = node->left;
            node->left = node->right;
            node->right = temp;
        } else if (currentLevel < k) {
            swapChildrenAtLevelHelper(node->left,  k, currentLevel + 1);
            swapChildrenAtLevelHelper(node->right, k, currentLevel + 1);
        }
    }
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

TreeNode* parseTreeNode(Queue<string>& tokenQueue) {
    if (tokenQueue.peek() == "(") {
        // start of a new node
        tokenQueue.dequeue();   // the "(" token
        int data = stringToInteger(tokenQueue.dequeue());
        TreeNode* node = new TreeNode(data);
        node->left = parseTreeNode(tokenQueue);
        node->right = parseTreeNode(tokenQueue);
        tokenQueue.dequeue();   // the ")" token
        return node;
    } else if (tokenQueue.peek() == "NULL" || tokenQueue.peek() == "/") {
        tokenQueue.dequeue();
        return NULL;
    } else {
        return NULL;
    }
}

TreeNode* makeTreeFromString(string s) {
    // make easier for tokenizing
    s = stringReplace(s, "(", "( ");
    s = stringReplace(s, ")", " ) ");
    s = stringReplace(s, ", ", " , ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    Vector<string> tokens = stringSplit(s, " ");
    Queue<string> tokenQueue;
    for (string token : tokens) {
        tokenQueue.enqueue(token);
    }
    TreeNode* root = parseTreeNodeFromQueue(tokenQueue);
    return root;
}

void printSideways(TreeNode* node, string indent = "") {
    if (node != NULL) {
        printSideways(node->right, indent + "  ");
        cout << indent << node->data << endl;
        printSideways(node->left, indent + "  ");
    }
}

static void test_binaryTreesWrite_helper(string treestr, int level) {
    TreeNode* root = makeTreeFromString(treestr);
    printSideways(root);

    cout << "before swapChildrenAtLevel(" << level << "):" << endl;
    try {
        swapChildrenAtLevel(root, level);
    } catch (...) {
        cout << "(threw exception!)" << endl;
    }
    cout << "after  swapChildrenAtLevel(" << level << "):" << endl;
    printSideways(root);
    cout << "-----" << endl;
}

void test_binaryTreesWrite(int problemNumber) {
    problemHeader(problemNumber, "Binary Trees (write)");
    string treestr = "(42 (19 (54) (32 (12))) (65 (23)))";
    test_binaryTreesWrite_helper(treestr, 2);
    test_binaryTreesWrite_helper(treestr, 1);
    test_binaryTreesWrite_helper(treestr, 4);
    test_binaryTreesWrite_helper(treestr, 0);
    test_binaryTreesWrite_helper(treestr, 5);
}
