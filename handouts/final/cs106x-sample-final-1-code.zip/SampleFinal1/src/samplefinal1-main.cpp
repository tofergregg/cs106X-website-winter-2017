/*
 * CS 106B/X, Marty Stepp
 * 
 * This program runs all of the various tests on each problem.
 * If you want to type in your solution to a given problem, open the problemXX.cpp
 * file for that problem and type your solution there.
 */

#include <iostream>
#include "console.h"
#include "gwindow.h"
#include "problems.h"

using namespace std;

int main() {
    test_linkedListsRead(1);
    test_linkedListsWrite(2);
    test_binarySearchTreesRead(3);
    test_binaryTreesWrite(4);
    test_hashingRead(5);
    test_graphsRead(6);
    test_graphsWrite(7);
    test_inheritanceRead(8);
    test_inheritanceWrite(9);

    cout << "All tests completed." << endl;
    return 0;
}

void problemHeader(int number, string title) {
    cout << endl << endl;
    cout << "Problem " << setw(2) << number << ": " << title << endl;
    cout << "---------------------------------------------" << endl;
}

void problemFooter() {
    cout << "---------------------------------------------" << endl;
}
