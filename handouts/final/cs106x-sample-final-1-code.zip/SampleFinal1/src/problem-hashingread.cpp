#include "problems.h"
#include "HashTableMap.h"

void test_hashingRead(int problemNumber) {
    problemHeader(problemNumber, "Hashing (read)");
    
    HashTableMap<int, int> map;
    map.setRehashLoadFactor(0.5);
    map.put(8, 11);
    map.put(26, 9);
    map.put(16, 9);
    map.put(26, 88);
    map.put(196, 44);
    map.put(38, 11);
    map.put(32, 77);
    map.remove(26);
    map.remove(9);
    map.put(100, 44);
    if (map.containsKey(196)) {
        map.remove(44);
    }
    map.put(56, 56);
    map.put(-48, 34);
    
    map.printStructure();

    problemFooter();
}
