#ifndef _graphsupport_h
#define _graphsupport_h

#include "problems.h"
#include <iostream>
#include <sstream>
using namespace std;

// colors for graph problems
typedef int Color;
extern const Color UNCOLORED, WHITE, GRAY, YELLOW, GREEN, RED, BLUE;
extern const int NUM_COLORS;
extern const Color COLORS[7];
extern const std::string COLOR_NAMES[7];

bool canReach(BasicGraph& graph, Vertex* start, Vertex* end, Vector<Vertex*>* path = NULL);
bool isConnected(BasicGraph& graph, bool checkWeak = false);
bool isCyclic(BasicGraph& graph);
void printEdgeList(BasicGraph& graph);
void printAdjacencyList(BasicGraph& graph);
void printAdjacencyMatrix(BasicGraph& graph);
void printVertexDegrees(BasicGraph& graph);
string pathToString(const Vector<Vertex*>& path);
void printPath(const Vector<Vertex*>& path);

#endif //_graphsupport_h
