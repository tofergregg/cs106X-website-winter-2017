#ifndef _problems_h
#define _problems_h

#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include "basicgraph.h"
#include "grid.h"
#include "hashmap.h"
#include "hashset.h"
#include "map.h"
#include "set.h"
#include "stack.h"
#include "queue.h"
#include "random.h"
#include "strlib.h"
#include "vector.h"
#include "ArrayList.h"
using namespace std;

void problemHeader(int number, string title);
void problemFooter();

void test_arrayListsWrite(int problemNumber);
void test_backtrackingWrite(int problemNumber);
void test_binarySearchTreesRead(int problemNumber);
void test_binaryTreesWrite(int problemNumber);
void test_graphsRead(int problemNumber);
void test_graphsWrite(int problemNumber);
void test_hashingRead(int problemNumber);
void test_inheritanceRead(int problemNumber);
void test_inheritanceWrite(int problemNumber);
void test_linkedListsRead(int problemNumber);
void test_linkedListsWrite(int problemNumber);

// colors for graph problems
typedef int Color;
extern const Color UNCOLORED, WHITE, GRAY, YELLOW, GREEN, RED, BLUE;
extern const int NUM_COLORS;
extern const Color COLORS[7];
extern const std::string COLOR_NAMES[7];

#endif
