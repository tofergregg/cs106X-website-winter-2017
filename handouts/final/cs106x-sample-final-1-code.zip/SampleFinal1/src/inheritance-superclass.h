#ifndef _inheritance_superclass_h
#define _inheritance_superclass_h

#include <iostream>
#include <string>
using namespace std;

class Dice {
public:
    Dice(int count);
    int getCount() const;
    int getValue(int index) const;
    void roll(int index);
    int total() const;
    string toString() const;

private:
    int* diceValues;
    int count;
};

ostream& operator <<(ostream& out, const Dice& dice);

#endif
