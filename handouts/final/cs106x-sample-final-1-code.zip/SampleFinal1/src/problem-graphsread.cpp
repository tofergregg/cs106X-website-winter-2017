#include "problems.h"
#include "graphsupport.h"

#include <iostream>
using namespace std;

void test_graphsRead(int problemNumber) {
    problemHeader(problemNumber, "Graphs (read)");

    BasicGraph graph;
    string graphStr = "{A, B, C, E, F, G, H, I, J, A -> B : 6, A -> E : 2, B -> A : 6, B -> F : 1, C -> B : 2, C -> G : 1, E -> F : 8, E -> H : 3, G -> F : 2, G -> J : 5, H -> I : 1, I -> F : 2, I -> J : 1}";
    istringstream iss(graphStr);
    iss >> graph;
    cout << "graph: " << graph << endl;
    
    cout << "(a)" << endl;
    cout << "directed? true" << endl;
    
    cout << "(b)" << endl;
    cout << "weighted? true" << endl;
    
    cout << "(c)" << endl;
    cout << "connected? " << boolalpha << isConnected(graph, /* checkWeak */ true) << endl;
    
    cout << "(d)" << endl;
    cout << "cyclic? " << boolalpha << isCyclic(graph) << endl;
    
    cout << "(e)" << endl;
    printVertexDegrees(graph);

    cout << "(f)" << endl;
    printAdjacencyList(graph);
    printAdjacencyMatrix(graph);
    
    cout << "(g)" << endl;
    cout << "(no code provided for DFS output)" << endl;
    
    cout << "(h)" << endl;
    cout << "(no code provided for BFS output)" << endl;

    problemFooter();
}
