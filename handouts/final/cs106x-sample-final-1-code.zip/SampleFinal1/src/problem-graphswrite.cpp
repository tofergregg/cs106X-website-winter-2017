#include "problems.h"
#include "simpio.h"
#include <iostream>
#include <sstream>

// ============================================================================
// || YOUR SOLUTION CODE GOES BELOW
// ============================================================================

// solution 1: two loops; each checks one way
bool containsBidiPath(BasicGraph& graph, Vector<Vertex*>& path) {
    // check that every vertex in the path is contained in the graph
    for (Vertex* v : path) {
        if (graph.getNode(v->name) != v) {
            return false;
        }
    }
    // check that each adjacent pair of vertices are neighbors
    for (int i = 0; i < path.size() - 1; i++) {
        Vertex* first = path[i];
        Vertex* second = path[i + 1];
        if (!graph.getNeighbors(first).contains(second)) {
            return false;
        }
    }
    for (int i = path.size() - 1; i > 0; i--) {
        Vertex* first = path[i];
        Vertex* second = path[i - 1];
        if (!graph.getNeighbors(first).contains(second)) {
            return false;
        }
    }
    return true;
}

// ============================================================================
// || YOUR SOLUTION CODE ENDS; TESTING CODE BEGINS
// ============================================================================

void printPath(Vector<Vertex*> path);
void readPath(BasicGraph& graph, string pathStr, Vector<Vertex*>& vpath);
void testGraph(string graphStr, string pathStr);

void test_graphsWrite(int problemNumber) {
    problemHeader(problemNumber, "Graphs (write)");

    // string graph1 = "{v1, v2, v3, v4, v5, v6, v1 - v2, v1 - v5, v2 - v3, v2 - v5, v3 - v4, v4 - v5, v4 - v6}";
    string graph1 = "{A, B, C, E, F, G, H, I, A -> B, A -> E, B -> A, B -> C, B -> F, C -> B, C -> G, E -> F, E -> H, F -> B, F -> G, F -> I, G -> F, I -> H}";
    string path1 = "{\"A\", \"B\", \"F\", \"G\"}";
    testGraph(graph1, path1);
    string path2 = "{\"A\", \"E\", \"F\", \"I\"}";
    testGraph(graph1, path2);
    string path3 = "{\"A\", \"X\", \"Z\", \"B\"}";
    testGraph(graph1, path3);

    problemFooter();
}

void testGraph(string graphStr, string pathStr) {
    BasicGraph graph;
    istringstream input(graphStr);
    input >> graph;
    cout << "graph: " << graph << endl;
    
    Vector<Vertex*> path;
    readPath(graph, pathStr, path);
    cout << "path : ";
    printPath(path);
    
    bool found = containsBidiPath(graph, path);
    cout << "  containsBidiPath() returned: " << boolalpha << found << endl;
    cout << endl;
}

void printPath(Vector<Vertex*> path) {
    cout << "{";
    int i = 0;
    for (Vertex* v : path) {
        if (i > 0) {
            cout << ", ";
        }
        if (!v) {
            cout << "NULL";
        } else {
            cout << v->name;
        }
        i++;
    }
    cout << "}" << endl;
}

void readPath(BasicGraph& graph, string pathStr, Vector<Vertex*>& vpath) {
    Vector<string> vpathStr;
    istringstream input(pathStr);
    input >> vpathStr;
    for (string vstr : vpathStr) {
        if (graph.containsVertex(vstr)) {
            vpath.add(graph.getVertex(vstr));
        } else {
            Vertex* dummy = new Vertex(vstr);     // not in graph
            vpath.add(dummy);
        }
    }
}
