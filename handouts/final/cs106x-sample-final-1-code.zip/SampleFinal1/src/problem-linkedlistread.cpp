#include "problems.h"

#include <iostream>
#include <string>
#include "vector.h"
#include "ListNode.h"
using namespace std;

extern void printChain(ListNode* list, string name, int maxLength = 20);
extern ListNode* vectorToList(Vector<int>& v);

void linkedListMystery1(ListNode*& front) {
    ListNode* curr = front;
    while (curr != nullptr) {
        if (curr->next != nullptr && curr->data > curr->next->data) {
            curr->data++;
            ListNode* temp = curr->next;
            curr->next = curr->next->next;
            temp->next = curr;
        }
        curr = curr->next;
    }
}

void test_linkedListsRead(int problemNumber) {
    problemHeader(problemNumber, "Linked Lists (read)");
    
    // front -> [10] -> [20] -> [40] -> [30] -> [90] -> [80] -> [70] -> [60] -> [100] -> [0] /
    Vector<int> v {10, 20, 40, 30, 90, 80, 70, 60, 100, 0};
    ListNode* front = vectorToList(v);

    linkedListMystery1(front);
    
    printChain(front, "front");
    problemFooter();
}
