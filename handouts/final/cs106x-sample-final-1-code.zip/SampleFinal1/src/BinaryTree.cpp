/*
 * This file contains the implementation of members of the BinaryTree class,
 * which defines a binary tree of integers.
 * See BinaryTree.h for a description of each member.
 */

#include "BinaryTree.h"
#include "random.h"
#include "strlib.h"

BinaryTree::BinaryTree(TreeNode* root) {
    this->root = root;
}

BinaryTree::~BinaryTree() {
    // TODO
    root = NULL;
}

bool BinaryTree::contains(int value) {
    return contains(root, value);
}

bool BinaryTree::contains(TreeNode* node, int value) {
    if (node == NULL) {
        return false;
    } else if (node->data == value) {
        return true;
    } else {
        return contains(node->left, value) ||
               contains(node->right, value);
    }
}

void BinaryTree::print() {
    print(root, 1);
}

void BinaryTree::print(TreeNode* node, int level) {
    if (node != NULL) {
        print(node->left, level+1);
        cout << node->data << " (" << level << ")" << endl;
        print(node->right, level+1);
    }
}

void BinaryTree::printSideways() {
    printSideways(root, "");
}

void BinaryTree::printSideways(TreeNode* node, string indent) {
    if (node != NULL) {
        printSideways(node->right, indent + "  ");
        cout << indent << node->data << endl;
        printSideways(node->left, indent + "  ");
    }
}

int BinaryTree::size() {
    return size(root);
}

int BinaryTree::size(TreeNode* node) {
    if (node == NULL) {
        return 0;
    } else {
        return 1 + size(node->left) + size(node->right);
    }
}

int BinaryTree::height() {
    return height(root);
}
int BinaryTree::height(TreeNode* node) {
    if (node == NULL) {
        return 0;
    } else {
        return 1 + max(height(node->left), height(node->right));
    }
}

string BinaryTree::toString() {
    return toString(root);
}
string BinaryTree::toString(TreeNode* node) {
    if (node == NULL) {
        return "/";
    } else if (node->left == NULL && node->right == NULL) {
        return integerToString(node->data);
    } else {
        return "(" + integerToString(node->data) + ", "
             + toString(node->left) + ", " + toString(node->right) + ")";
    }
}

void BinaryTree::deleteTree(TreeNode* node) {
    if (node != NULL) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }
}

TreeNode* parseTreeNodeFromQueue(Queue<string>& tokenQueue) {
    if (tokenQueue.peek() == "(") {
        // start of a new node
        tokenQueue.dequeue();   // the "(" token
        int data = stringToInteger(tokenQueue.dequeue());
        TreeNode* node = new TreeNode(data);
        node->left = parseTreeNodeFromQueue(tokenQueue);
        node->right = parseTreeNodeFromQueue(tokenQueue);
        tokenQueue.dequeue();   // the ")" token
        return node;
    } else if (tokenQueue.peek() == "NULL") {
        tokenQueue.dequeue();
        return NULL;
    } else {
        return NULL;
    }
}

void makeTreeFromString(BinaryTree& tree, string s) {
    // make easier for tokenizing
    s = stringReplace(s, "(", "( ");
    s = stringReplace(s, ")", " ) ");
    s = stringReplace(s, ", ", " , ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    s = stringReplace(s, "  ", " ");
    Vector<string> tokens = stringSplit(s, " ");
    Queue<string> tokenQueue;
    for (string token : tokens) {
        tokenQueue.enqueue(token);
    }
    tree.root = parseTreeNodeFromQueue(tokenQueue);
}
