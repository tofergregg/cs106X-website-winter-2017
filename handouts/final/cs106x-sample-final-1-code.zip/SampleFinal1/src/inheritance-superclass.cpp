#include "inheritance-superclass.h"
#include <climits>
#include <iomanip>
#include <sstream>
#include "random.h"

Dice::Dice(int count) {
    this->diceValues = new int[count]();
    this->count = count;
}

int Dice::getCount() const {
    return count;
}

int Dice::getValue(int index) const {
    return diceValues[index];
}

void Dice::roll(int index) {
    if (index < 0 || index >= count) {
        throw index;
    }
    diceValues[index] = randomInteger(1, 6);
}

int Dice::total() const {
    int count = 0;
    for (int i = 0; i < count; i++) {
        count += diceValues[i];
    }
    return count;
}

string Dice::toString() const {
    ostringstream out;
    out << "{";
    if (count > 0) {
        out << diceValues[0];
        for (int i = 1; i < count; i++) {
            out << ", " << diceValues[i];
        }
    }
    out << "}";
    return out.str();
}

ostream& operator <<(ostream& out, const Dice& dice) {
    out << dice.toString();
    return out;
}
