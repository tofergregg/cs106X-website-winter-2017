/*
 * CS 106B, Marty Stepp
 * ArrayList.cpp implements the ArrayList class behavior declared in ArrayList.h.
 */

#include "ArrayList.h"
#include "strlib.h"
using namespace std;

/*
 * Constructs a new empty list (capacity 10).
 */
ArrayList::ArrayList() {
    myElements = new int[10]();
    mySize = 0;
    myCapacity = 10;
}

/*
 * Constructs a new empty list with the given capacity.
 */
ArrayList::ArrayList(int capacity) {
    myElements = new int[capacity]();
    mySize = 0;
    myCapacity = capacity;
}

/*
 * Destructor is called when an ArrayList object is destroyed
 * (when the closing } brace is reached in the function where
 * it is declared).
 */
ArrayList::~ArrayList() {
    delete[] myElements;
}

/*
 * Appends the given value to the end of the list.
 */
void ArrayList::add(int value) {
    ensureCapacity(mySize + 1);
    myElements[mySize] = value;
    mySize++;
}

/*
 * Removes all elements from the list.
 */
void ArrayList::clear() {
    mySize = 0;
}

/*
 * Returns the value at the given 0-based index of the list.
 */
int ArrayList::get(int index) const {
    checkIndex(index, 0, mySize - 1);
    return myElements[index];
}

/*
 * Adds the given value just before the given 0-based index in the list,
 * shifting subsequent elements right as necessary to make room.
 * Throws a string exception if the index is out of bounds.
 */
void ArrayList::insert(int index, int value) {
    checkIndex(index, 0, mySize);
    ensureCapacity(mySize + 1);
    for (int i = mySize; i > index; i--) {
        myElements[i] = myElements[i - 1];
    }
    myElements[index] = value;
    mySize++;
}

/*
 * Returns true if there are no elements in the list.
 */
bool ArrayList::isEmpty() const {
    return mySize == 0;
}

/*
 * Removes the element at the given index from the list,
 * shifting elements left to make room.
 * Throws a string exception if the index is out of bounds.
 */
void ArrayList::remove(int index) {
    checkIndex(index, 0, mySize - 1);
    for (int i = index; i < mySize - 1; i++) {
        myElements[i] = myElements[i + 1];
    }
    mySize--;
}

/*
 * Stores the given value at the given index in the list.
 * Throws a string exception if the index is out of bounds.
 */
void ArrayList::set(int index, int value) {
    checkIndex(index, 0, mySize - 1);
    myElements[index] = value;
}

/*
 * Returns the number of elements in the list.
 */
int ArrayList::size() const {
    return mySize;
}

/*
 * Prints the list to the given output stream, in a format such as:
 * {42, -7, 19, 106}
 */
ostream& operator <<(ostream& out, ArrayList& list) {
    out << "{";
    if (!list.isEmpty()) {
        out << list.get(0);   // fencepost
        for (int i = 1; i < list.size(); i++) {
            out << ", " << list.get(i);
        }
    }
    out << "}";
    return out;
}

/*
 * Throws a string exception if the given index is not between
 * min and max, inclusive.
 */
void ArrayList::checkIndex(int index, int min, int max) const {
    if (index < min || index > max) {
        throw "Index out of bounds: " + integerToString(index);
    }
}

/*
 * Grows the internal array to be at least as large as the given capacity.
 * Resizes by factors of 2 to ensure amortized O(1) add performance.
 */
void ArrayList::ensureCapacity(int cap) {
    if (myCapacity < cap) {
        while (myCapacity < cap) {
            myCapacity *= 2;
        }
        
        // copy all elements into a bigger array
        int* bigger = new int[myCapacity];
        for (int i = 0; i < mySize; i++) {
            bigger[i] = myElements[i];
        }
        
        // swap in the new bigger array for the old one
        delete[] myElements;
        myElements = bigger;
    }
}
