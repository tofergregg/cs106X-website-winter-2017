#include "graphsupport.h"
#include "problems.h"
#include <iostream>
#include <sstream>
using namespace std;

// definitions for colors
const int NUM_COLORS = 7;

const Color UNCOLORED = 0;
const Color WHITE = 1;
const Color GRAY = 2;
const Color YELLOW = 3;
const Color GREEN = 4;
const Color RED = 5;
const Color BLUE = 6;

const Color COLORS[7] = {
    UNCOLORED,
    WHITE,
    GRAY,
    YELLOW,
    GREEN,
    RED,
    BLUE
};

const string COLOR_NAMES[7] = {
    "uncolored",
    "white",
    "gray",
    "yellow",
    "green",
    "red",
    "blue"
};

bool canReach(BasicGraph& graph, Vertex* start, Vertex* end, Vector<Vertex*>* path) {
    // cout << "    canReach(graph, start=" << start->name << ", end=" << end->name << ")" << endl;
    if (start == end) {
        return true;
    } else if (start->visited) {
        return false;
    } else {
        start->visited = true;
        if (path != NULL) {
            path->add(start);
        }
        for (Vertex* neighbor : graph.getNeighbors(start)) {
            if (canReach(graph, neighbor, end, path)) {
                return true;
            }
        }
        start->visited = false;
        if (path != NULL) {
            path->remove(path->size() - 1);
        }
        return false;
    }
}

bool isConnected(BasicGraph& graph, bool checkWeak) {
    bool weak = false;
    for (Vertex* v1 : graph.getVertexSet()) {
        for (Vertex* v2 : graph.getVertexSet()) {
            if (v1 == v2) {
                continue;
            }
            // cout << "    " << v1->name << " ... " << v2->name << endl;
            graph.resetData();
            if (!canReach(graph, v1, v2)) {
                if (checkWeak && canReach(graph, v2, v1)) {
                    weak = true;
                    continue;
                }
                cout << "vertex " << v1->name << " cannot reach " << v2->name << endl;
                return false;
            }
        }
    }
    
    if (weak) {
        cout << "(weakly connected)" << endl;
    }
    return !weak;
}

bool isCyclic(BasicGraph& graph) {
    for (Vertex* v : graph.getVertexSet()) {
        for (Vertex* neighbor : graph.getNeighbors(v)) {
            Vector<Vertex*> path;
            graph.resetData();
            if (canReach(graph, neighbor, v, &path)) {
                path.insert(0, v);
                path.add(v);
                cout << "cycle starting from " << v->name << ": " << pathToString(path) << endl;
                return true;
            }
        }
    }
    
    return false;
}

void printEdgeList(BasicGraph& graph) {
    cout << "edge list:" << endl;
    Vector<string> edgeList;
    for (Edge* edge : graph.getEdgeSet()) {
        string edgeStr = "" + edge->start->name + " -> " + edge->finish->name;
        if (edge->weight != 0) {
            edgeStr += " : " + realToString(edge->weight);
        }
        cout << "  " << edgeStr << endl;
    }
}

void printAdjacencyList(BasicGraph& graph) {
    cout << "adjacency list:" << endl;
    for (Vertex* v : graph.getVertexSet()) {
        cout << "  " << v->name << " : ";
        int count = 0;
        for (Vertex* neighbor : graph.getNeighbors(v)) {
            if (count > 0) {
                cout << ", ";
            }
            cout << "(" << neighbor->name;
            Edge* edge = graph.getEdge(v, neighbor);
            if (edge->weight != 0) {
                cout << ":" << edge->weight;
            }
            count++;
            cout << ")";
        }
        cout << endl;
    }
}

void printAdjacencyMatrix(BasicGraph& graph) {
    cout << "adjacency matrix:" << endl;
    
    const int COL_WIDTH = 5;
    
    // column headers
    cout << setw(COL_WIDTH) << "";
    for (Vertex* v1 : graph.getVertexSet()) {
        cout << setw(COL_WIDTH) << v1->name;
    }
    cout << endl;
    
    for (Vertex* v1 : graph.getVertexSet()) {
        // row header
        cout << setw(COL_WIDTH) << v1->name;
        
        for (Vertex* v2 : graph.getVertexSet()) {
            double toPrint = 0;
            if (graph.isNeighbor(v1, v2)) {
                Edge* edge = graph.getEdge(v1, v2);
                if (edge->weight != 0) {
                    toPrint = edge->weight;
                } else {
                    toPrint = 1;
                }
            }
            cout << setw(COL_WIDTH) << toPrint;
        }
        cout << endl;
    }
}

void printVertexDegrees(BasicGraph& graph) {
    cout << "vertex degrees:" << endl;
    for (Vertex* v : graph.getVertexSet()) {
        cout << "  " << v->name << " : ";
        int inDegree = 0;
        for (Vertex* v2 : graph.getVertexSet()) {
            if (graph.isNeighbor(v2, v)) {
                inDegree++;
            }
        }
        cout << "in-degree: " << inDegree;
        cout << ", out-degree: " << v->edges.size() << endl;
    }
}

string pathToString(const Vector<Vertex*>& path) {
    Vector<string> path2;
    for (Vertex* v : path) {
        if (v == NULL) {
            path2.add("NULL");
        } else {
            path2.add(v->name);
        }
    }
    return path2.toString();
}

void printPath(const Vector<Vertex*>& path) {
    cout << "{";
    int i = 0;
    for (Vertex* v : path) {
        if (i > 0) {
            cout << ", ";
        }
        if (!v) {
            cout << "NULL";
        } else {
            cout << v->name;
        }
        i++;
    }
    cout << "}" << endl;
}
