// Your first program!

#include <iostream>
#include "console.h"

using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
