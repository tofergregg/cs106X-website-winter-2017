// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include <string>
#include "set.h"
using namespace std;

int findAnagrams(const string& phrase, int max, const Set<string>& dictionary) {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}
