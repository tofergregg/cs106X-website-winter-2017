#include <iostream>
#include <ctype.h> // for isspace, isalpha
#include "console.h"
#include "simpio.h"  // for getLine
#include "string.h"
#include "vector.h"  // for Vector
#include "lexicon.h"
using namespace std;

// Transposition Cipher

const char PAD = '~'; // padding character for cipher
const int MAX_KEY_LEN = 9;
const int TOP_X = 5;

struct DecryptionGuess {
    string potentialPlaintext;
    double wordPercentage;
};

// New function prototypes for assignment 4
void bruteForce(Vector<DecryptionGuess> &topX, string ciphertext, int keyLen);
string alphaAndSpaceOnly(string s);

/* Your code from assignment 2, starting at your function prototypes
 * should be pasted here. It should work the same as assignment 2, except that it
 * should have an additional menu item:
 *
 * 3) brute force decrypt without the key
 *
 */

void bruteForce(Vector<DecryptionGuess> &topX, string ciphertext, int keyLen) {

}

string alphaAndSpaceOnly(string s) {
   return ""; // here only so this will compile
}
