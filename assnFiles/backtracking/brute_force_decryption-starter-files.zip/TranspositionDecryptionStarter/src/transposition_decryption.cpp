#include <iostream>
#include <ctype.h> // for isspace, isalpha
#include "console.h"
#include "simpio.h"  // for getLine
#include "string.h"
#include "vector.h"  // for Vector
#include "lexicon.h"
using namespace std;

// Transposition Cipher

const char PAD = '~'; // padding character for cipher
const int MAX_KEY_LEN = 9;
const int TOP_X = 5;

struct DecryptionGuess {
    string potentialPlaintext;
    double wordPercentage;
};

// New function prototypes for assignment 4
Vector<DecryptionGuess> bruteForce(string ciphertext);
string alphaAndSpaceOnly(string s);

/* Your code from assignment 2, starting at your function prototypes
 * should be pasted here. It should work the same as assignment 2, except that it
 * should have an additional menu item:
 *
 * 3) brute force decrypt without the key
 *
 */

/* This function produces a vector of DecryptionGuess structs that holds
 * the top X number of best-guesses based on a brute force decryption
 * of a ciphertext.
 */
Vector<DecryptionGuess> bruteForce(string ciphertext) {

}

/* This function returns a string with the following properties:
 * 1. It only has alphabetic characters and spaces, and
 * 2. All space-like characters (newline, tab) have been
 *    converted to spaces (' ')
 */
string alphaAndSpaceOnly(string s) {
   return ""; // here only so this will compile
}
