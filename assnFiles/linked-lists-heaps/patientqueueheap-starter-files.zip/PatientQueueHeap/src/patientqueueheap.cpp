// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "patientqueueheap.h"

// Big O:
PatientQueue::PatientQueue() {
    // TODO: write this constructor
}

// Big O:
PatientQueue::~PatientQueue() {
    // TODO: write this destructor
}

// Big O:
void PatientQueue::clear() {
    // TODO: write this function
}

// Big O:
string PatientQueue::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

// Big O:
int PatientQueue::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

// Big O:
bool PatientQueue::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

// Big O:
void PatientQueue::newPatient(string name, int priority) {
    // TODO: write this function
}

// Big O:
string PatientQueue::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

// Big O:
void PatientQueue::upgradePatient(string name, int newPriority) {
    // TODO: write this function
}

// Big O:
ostream& operator <<(ostream& out, const PatientQueue& queue) {
    // TODO: write this function
    return out;
}
