// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "patientqueue.h"

PatientQueue::PatientQueue() {
    // TODO: write this constructor
}

PatientQueue::~PatientQueue() {
    // TODO: write this destructor
}

void PatientQueue::clear() {
    // TODO: write this function
}

string PatientQueue::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

int PatientQueue::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

bool PatientQueue::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

void PatientQueue::newPatient(string name, int priority) {
    // TODO: write this function
}

string PatientQueue::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

void PatientQueue::upgradePatient(string name, int newPriority) {
    // TODO: write this function
}

ostream& operator <<(ostream& out, const PatientQueue& queue) {
    // TODO: write this function
    return out;
}
