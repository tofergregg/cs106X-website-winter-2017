// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include <iostream>
using namespace std;

bool playQuestionGame(istream& input) {
    // TODO: write this function
    
    return false;
}
