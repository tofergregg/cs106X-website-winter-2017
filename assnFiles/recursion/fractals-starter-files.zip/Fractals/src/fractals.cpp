// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "fractals.h"
using namespace std;

void drawSierpinskiTriangle(GWindow& window, double x, double y, double size, int order) {
    // TODO: write this function

}

void drawTree(GWindow& window, double x, double y, double size, int order) {
    // TODO: write this function

}

int floodFill(GWindow& window, int x, int y, int color) {
    // TODO: write this function

    return 0;   // this is only here so it will compile
}
