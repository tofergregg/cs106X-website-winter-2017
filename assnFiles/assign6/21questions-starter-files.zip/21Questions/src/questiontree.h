// This is the H file you will edit and turn in. (TODO: Remove this comment!)

#ifndef _questiontree_h
#define _questiontree_h

#include <iostream>
#include <string>
#include "questionnode.h"

class QuestionTree {
public:
    QuestionTree();
    ~QuestionTree();
    int getGamesLost() const;
    int getGamesWon() const;
    void playGame();
    void readData(std::istream& input);
    void writeData(std::ostream& output);

private:
    // TODO: declare needed private members here
    
};

#endif // _questiontree_h
