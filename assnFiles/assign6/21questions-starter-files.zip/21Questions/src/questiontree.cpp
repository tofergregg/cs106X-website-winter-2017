// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "questiontree.h"
using namespace std;

QuestionTree::QuestionTree() {
    // TODO: write this constructor

}

QuestionTree::~QuestionTree() {
    // TODO: write this destructor

}

int QuestionTree::getGamesLost() const {
    // TODO: write this member function
    return 0;   // this is only here so it will compile
}

int QuestionTree::getGamesWon() const {
    // TODO: write this member function
    return 0;   // this is only here so it will compile
}

void QuestionTree::playGame() {
    // TODO: write this member function

}

void QuestionTree::readData(istream& input) {
    // TODO: write this member function

}

void QuestionTree::writeData(ostream& output) {
    // TODO: write this member function

}
