// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include <iostream>
#include "console.h"
using namespace std;

int main() {
    // TODO: Finish the program!

    cout << "Have a nice day." << endl;
    return 0;
}
